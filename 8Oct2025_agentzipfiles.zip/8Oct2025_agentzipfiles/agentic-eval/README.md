# Agentic AI + MCP Candidate Evaluation System

This project demonstrates an end-to-end agentic AI system using:
- 🧠 **LangChain + LangGraph** for agent orchestration
- 🔧 **Anthropic MCP SDK** to wrap tools (API, database, scoring)
- 🤖 **OpenAI GPT-4** for reasoning and decision-making

## 📋 Prerequisites

- Python 3.9 or higher
- OpenAI API key (get from https://platform.openai.com/api-keys)

## 🚀 Quick Start

### 1. Extract the ZIP file
```bash
unzip agentic-eval.zip
cd agentic-eval
```

### 2. Create a virtual environment (recommended)
```bash
# Using venv
python -m venv venv

# Activate on Windows
venv\Scripts\activate

# Activate on Mac/Linux
source venv/bin/activate

# Or using Anaconda (as you prefer)
conda create -n agentic-eval python=3.10
conda activate agentic-eval
```

### 3. Install dependencies
```bash
pip install -r requirements.txt
```

### 4. Configure environment variables
```bash
# Copy the example file
cp .env.example .env

# Edit .env and add your OpenAI API key
# On Windows: notepad .env
# On Mac/Linux: nano .env
```

Replace `your-openai-api-key-here` with your actual OpenAI API key.

### 5. Run the agent
```bash
python agent_client.py
```

## 🧪 How It Works

1. **LangGraph Agent** receives a candidate evaluation prompt
2. **GPT-4** reasons: "I need candidate data and scoring information"
3. Agent **calls MCP tools**:
   - `fetch_candidate_data("Asha")` - Gets candidate profile
   - `score_candidate(["Python", "ML"], ["Python", "ML", "SQL"])` - Calculates match score
4. **GPT-4 synthesizes** the information and provides evaluation:
   - "Asha matches 2 of 3 required skills. Score: 66.67%. Recommendation: Interview with SQL assessment."

## 📁 Project Structure

```
agentic-eval/
├── .env.example          # Template for environment variables
├── .env                  # Your actual API keys (create from .env.example)
├── tools_server.py       # MCP server with candidate evaluation tools
├── agent_client.py       # LangGraph agent using GPT-4
├── requirements.txt      # Python dependencies
└── README.md            # This file
```

## 🔧 Customization

### Add More Candidates
Edit `tools_server.py` and add entries to the `candidates` dictionary:

```python
candidates = {
    "Asha": {
        "name": "Asha",
        "skills": ["Python", "ML"],
        "experience": 3,
        "score": 82
    },
    "John": {
        "name": "John",
        "skills": ["Java", "Spring", "SQL"],
        "experience": 5,
        "score": 90
    }
}
```

### Change the Evaluation Prompt
Modify the message in `agent_client.py`:

```python
result = await agent.ainvoke({
    "messages": [("user", "Your custom evaluation prompt here")]
})
```

### Use Different OpenAI Models
In `agent_client.py`, change the model parameter:

```python
llm = ChatOpenAI(
    model="gpt-4-turbo",  # or "gpt-3.5-turbo" for faster/cheaper
    temperature=0,
    api_key=api_key
)
```

## 🛠️ Troubleshooting

### Import errors
```bash
pip install --upgrade -r requirements.txt
```

### API key issues
- Ensure `.env` file exists in the project root
- Verify your OpenAI API key is correct
- Check you have credits in your OpenAI account

### Python version issues
This project requires Python 3.9+. Check your version:
```bash
python --version
```

## 📝 Best Practices

- ✅ Never commit `.env` to version control
- ✅ Use `.env.example` to share configuration templates
- ✅ Keep dependencies updated regularly
- ✅ Use virtual environments to isolate project dependencies

## 🎯 Next Steps

- Add more MCP tools (e.g., email sender, calendar checker)
- Connect to real databases instead of mock data
- Implement multi-agent workflows with LangGraph
- Add logging and monitoring
- Deploy as a microservice

## 📚 Resources

- [LangChain Documentation](https://python.langchain.com/)
- [LangGraph Documentation](https://langchain-ai.github.io/langgraph/)
- [Anthropic MCP SDK](https://github.com/anthropics/anthropic-mcp-sdk-python)
- [OpenAI API Reference](https://platform.openai.com/docs/)

---

Built with ❤️ using LangChain + LangGraph + MCP
