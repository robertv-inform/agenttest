# agent_client.py
import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

from mcp.client.stdio import stdio_client
from mcp import ClientSession, StdioServerParameters
from langchain_openai import ChatOpenAI
from langchain_mcp_adapters.tools import load_mcp_tools
from langgraph.prebuilt import create_react_agent

async def run_agent():
    """Run the agent to evaluate a candidate."""

    # Check if API key is set
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key or api_key == "your-openai-api-key-here":
        print("❌ ERROR: Please set your OPENAI_API_KEY in the .env file")
        return

    # Configure MCP server parameters
    server_params = StdioServerParameters(
        command="python",
        args=["tools_server.py"]
    )

    # Connect to MCP server and create agent
    async with stdio_client(server_params) as (read, write):
        async with ClientSession(read, write) as session:
            await session.initialize()

            # Load MCP tools
            tools = await load_mcp_tools(session)
            print(f"✅ Loaded {len(tools)} MCP tools: {[tool.name for tool in tools]}")

            # Create LLM instance
            llm = ChatOpenAI(
                model="gpt-4",  # Use gpt-4, gpt-4-turbo, or gpt-3.5-turbo
                temperature=0,
                api_key=api_key
            )

            # Create ReAct agent with LangGraph
            agent = create_react_agent(
                model=llm,
                tools=tools
            )

            print("\n🤖 Running agent evaluation...\n")

            # Run the agent with evaluation task
            result = await agent.ainvoke({
                "messages": [("user", "Evaluate candidate Asha for ML Engineer role requiring Python, ML, and SQL.")]
            })

            # Print the final response
            print("\n" + "="*60)
            print("📊 AGENT RESPONSE:")
            print("="*60)
            print(result["messages"][-1].content)
            print("="*60 + "\n")

if __name__ == "__main__":
    import asyncio
    asyncio.run(run_agent())
