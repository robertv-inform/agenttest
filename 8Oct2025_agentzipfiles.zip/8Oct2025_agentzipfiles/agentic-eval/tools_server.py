# tools_server.py
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("CandidateTools")

@mcp.tool()
def fetch_candidate_data(candidate_id: str) -> dict:
    """Fetch candidate data from database (simulated)."""
    # Simulated DB/API call
    candidates = {
        "Asha": {
            "name": "Asha",
            "skills": ["Python", "ML"],
            "experience": 3,
            "score": 82
        },
        "default": {
            "name": candidate_id,
            "skills": ["Python", "ML"],
            "experience": 3,
            "score": 82
        }
    }
    return candidates.get(candidate_id, candidates["default"])

@mcp.tool()
def score_candidate(skills: list, job_requirements: list) -> float:
    """Score a candidate based on skill match with job requirements."""
    if not job_requirements:
        return 0.0
    match = len(set(skills) & set(job_requirements)) / len(job_requirements)
    return round(match * 100, 2)

if __name__ == "__main__":
    mcp.run(transport="stdio")
