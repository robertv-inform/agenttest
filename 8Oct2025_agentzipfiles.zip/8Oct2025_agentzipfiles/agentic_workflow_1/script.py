
import os

# Create remaining configuration files

# mcp_config/servers.json
os.makedirs("tender-agentic-mcp-system/mcp_config", exist_ok=True)
servers_json = """{
  "mcpServers": {
    "tender-analysis": {
      "command": "python",
      "args": ["-m", "app.mcp_servers.tender_analysis_server"],
      "env": {
        "PYTHONPATH": "."
      }
    },
    "vendor-search": {
      "command": "python",
      "args": ["-m", "app.mcp_servers.vendor_search_server"],
      "env": {
        "PYTHONPATH": "."
      }
    },
    "compliance-check": {
      "command": "python",
      "args": ["-m", "app.mcp_servers.compliance_server"],
      "env": {
        "PYTHONPATH": "."
      }
    }
  }
}
"""

with open("tender-agentic-mcp-system/mcp_config/servers.json", 'w') as f:
    f.write(servers_json)

# Dockerfile
dockerfile = """FROM python:3.11-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

RUN mkdir -p data/tenders data/vendors data/vector_db

EXPOSE 8000

CMD ["python", "run.py"]
"""

with open("tender-agentic-mcp-system/Dockerfile", 'w') as f:
    f.write(dockerfile)

# docker-compose.yml
docker_compose = """version: '3.8'

services:
  tender-system:
    build: .
    container_name: tender-agentic-mcp
    ports:
      - "8000:8000"
    environment:
      - OPENAI_API_KEY=${OPENAI_API_KEY}
      - OPENAI_MODEL=gpt-4o
      - EMBEDDING_MODEL=text-embedding-3-large
    volumes:
      - ./data:/app/data
      - ./.env:/app/.env
    restart: unless-stopped
"""

with open("tender-agentic-mcp-system/docker-compose.yml", 'w') as f:
    f.write(docker_compose)

# .gitignore
gitignore = """__pycache__/
*.py[cod]
*$py.class
*.so
.Python
build/
develop-eggs/
dist/
downloads/
eggs/
.eggs/
lib/
lib64/
parts/
sdist/
var/
wheels/
*.egg-info/
.installed.cfg
*.egg

# Environment
.env
.venv
env/
venv/
ENV/
env.bak/
venv.bak/

# IDE
.idea/
.vscode/
*.swp
*.swo
*~

# Data
data/vector_db/*
*.db
*.sqlite

# OS
.DS_Store
Thumbs.db
"""

with open("tender-agentic-mcp-system/.gitignore", 'w') as f:
    f.write(gitignore)

print("✓ Created mcp_config/servers.json")
print("✓ Created Dockerfile")
print("✓ Created docker-compose.yml")
print("✓ Created .gitignore")
