
# Create sample data files for testing
os.makedirs("tender-agentic-mcp-system/data/tenders", exist_ok=True)
os.makedirs("tender-agentic-mcp-system/data/vendors", exist_ok=True)
os.makedirs("tender-agentic-mcp-system/data/vector_db", exist_ok=True)

# Sample tender data
sample_tender = """{
  "tender_id": "TND001",
  "title": "Enterprise Software Development",
  "description": "Develop a comprehensive enterprise resource planning system with modern architecture",
  "requirements": "Python, FastAPI, React, PostgreSQL, Docker, Kubernetes, Microservices architecture, RESTful APIs, CI/CD pipeline",
  "budget": 500000,
  "deadline": "2025-12-31T00:00:00",
  "category": "IT Services",
  "technical_specs": {
    "languages": ["Python", "JavaScript", "TypeScript"],
    "frameworks": ["FastAPI", "React", "Django"],
    "databases": ["PostgreSQL", "Redis"],
    "cloud": ["AWS", "Azure"],
    "experience_required": "10+ years"
  }
}
"""

with open("tender-agentic-mcp-system/data/tenders/sample_tender.json", 'w') as f:
    f.write(sample_tender)

# Sample vendor data
sample_vendors = """[
  {
    "vendor_id": "VND001",
    "name": "TechCorp Solutions",
    "expertise": ["Python", "FastAPI", "React", "PostgreSQL", "Microservices"],
    "past_projects": [
      "E-commerce Platform for Fortune 500",
      "Banking System Modernization",
      "Healthcare Management System"
    ],
    "certifications": ["ISO 9001", "ISO 27001", "SOC 2"],
    "rating": 4.8,
    "capabilities": "Full-stack development with 50+ senior engineers specialized in enterprise systems",
    "years_experience": 15
  },
  {
    "vendor_id": "VND002",
    "name": "DevMasters Inc",
    "expertise": ["Java", "Spring Boot", "Angular", "Oracle", "Cloud Architecture"],
    "past_projects": [
      "ERP System for Manufacturing",
      "Supply Chain Management Platform"
    ],
    "certifications": ["ISO 9001", "CMMI Level 5"],
    "rating": 4.5,
    "capabilities": "Enterprise application development with 30+ developers",
    "years_experience": 12
  },
  {
    "vendor_id": "VND003",
    "name": "AI Innovations Ltd",
    "expertise": ["Python", "Django", "Vue.js", "MongoDB", "Machine Learning", "AI"],
    "past_projects": [
      "AI-powered Recommendation System",
      "Predictive Analytics Platform"
    ],
    "certifications": ["ISO 27001", "AWS Partner"],
    "rating": 4.7,
    "capabilities": "AI/ML integration with modern web development",
    "years_experience": 8
  }
]
"""

with open("tender-agentic-mcp-system/data/vendors/sample_vendors.json", 'w') as f:
    f.write(sample_vendors)

# Create a sample usage script
usage_example = """#!/usr/bin/env python3
\"\"\"
Sample usage script for Tender Agentic AI System
Run this after starting the server with: python run.py
\"\"\"

import requests
import json
from datetime import datetime

BASE_URL = "http://localhost:8000"

def test_health():
    \"\"\"Test health endpoint\"\"\"
    response = requests.get(f"{BASE_URL}/health")
    print("Health Check:", response.json())
    print()

def add_sample_vendors():
    \"\"\"Add sample vendors to vector store\"\"\"
    vendors = [
        {
            "vendor_id": "VND001",
            "name": "TechCorp Solutions",
            "expertise": ["Python", "FastAPI", "React", "PostgreSQL"],
            "past_projects": ["E-commerce Platform", "Banking System"],
            "certifications": ["ISO 9001", "ISO 27001"],
            "rating": 4.8,
            "capabilities": "Full-stack development with 50+ engineers",
            "years_experience": 15
        },
        {
            "vendor_id": "VND002",
            "name": "AI Innovations Ltd",
            "expertise": ["Python", "Django", "Machine Learning"],
            "past_projects": ["AI Recommendation System"],
            "certifications": ["ISO 27001"],
            "rating": 4.7,
            "capabilities": "AI/ML integration",
            "years_experience": 8
        }
    ]
    
    response = requests.post(
        f"{BASE_URL}/api/v1/data/vendors",
        json=vendors
    )
    print("Add Vendors:", response.json())
    print()

def analyze_tender():
    \"\"\"Analyze a tender\"\"\"
    tender_data = {
        "tender_data": {
            "tender_id": "TND001",
            "title": "Software Development",
            "description": "Enterprise application development",
            "requirements": "Python, FastAPI, React, PostgreSQL",
            "budget": 500000,
            "deadline": "2025-12-31T00:00:00",
            "category": "IT Services",
            "technical_specs": {
                "languages": ["Python", "JavaScript"]
            }
        }
    }
    
    response = requests.post(
        f"{BASE_URL}/api/v1/tender/analyze",
        json=tender_data
    )
    print("Tender Analysis:")
    print(json.dumps(response.json(), indent=2))
    print()

def evaluate_tender():
    \"\"\"Full tender evaluation with agentic workflow\"\"\"
    tender_data = {
        "tender_data": {
            "tender_id": "TND001",
            "title": "Software Development",
            "description": "Enterprise application development",
            "requirements": "Python, FastAPI, React, PostgreSQL",
            "budget": 500000,
            "deadline": "2025-12-31T00:00:00",
            "category": "IT Services"
        }
    }
    
    response = requests.post(
        f"{BASE_URL}/api/v1/tender/evaluate",
        json=tender_data
    )
    print("Tender Evaluation:")
    print(json.dumps(response.json(), indent=2))
    print()

def search_vendors():
    \"\"\"Search vendors by requirements\"\"\"
    response = requests.get(
        f"{BASE_URL}/api/v1/search/vendors",
        params={"query": "Python FastAPI development", "top_k": 5}
    )
    print("Vendor Search:")
    print(json.dumps(response.json(), indent=2))
    print()

if __name__ == "__main__":
    print("=" * 60)
    print("Tender Agentic AI System - Usage Examples")
    print("=" * 60)
    print()
    
    print("1. Testing health endpoint...")
    test_health()
    
    print("2. Adding sample vendors...")
    add_sample_vendors()
    
    print("3. Analyzing tender...")
    analyze_tender()
    
    print("4. Searching vendors...")
    search_vendors()
    
    print("5. Full tender evaluation (this may take 10-30 seconds)...")
    evaluate_tender()
    
    print("=" * 60)
    print("All tests completed!")
    print("=" * 60)
"""

with open("tender-agentic-mcp-system/example_usage.py", 'w') as f:
    f.write(usage_example)

print("✓ Created sample_tender.json")
print("✓ Created sample_vendors.json")
print("✓ Created example_usage.py")
