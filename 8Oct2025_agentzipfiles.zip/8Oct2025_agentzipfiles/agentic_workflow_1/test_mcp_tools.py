import pytest
from datetime import datetime

def test_mcp_tool_registration():
    """Test MCP tools are properly registered"""
    from app.mcp_servers.tender_analysis_server import mcp as tender_mcp
    from app.mcp_servers.vendor_search_server import mcp as vendor_mcp
    from app.mcp_servers.compliance_server import mcp as compliance_mcp

    # Check tools are registered
    assert tender_mcp is not None
    assert vendor_mcp is not None
    assert compliance_mcp is not None

def test_analyze_tender_tool():
    """Test tender analysis tool"""
    from app.mcp_servers.tender_analysis_server import analyze_tender

    tender_data = {
        "tender_id": "TEST001",
        "title": "Software Development",
        "description": "Enterprise application development",
        "requirements": "Python, FastAPI, React",
        "budget": 100000,
        "deadline": "2025-12-31",
        "category": "IT Services"
    }

    result = analyze_tender("TEST001", tender_data)
    assert result["status"] == "success"
    assert "analysis" in result

def test_search_vendors_tool():
    """Test vendor search tool"""
    from app.mcp_servers.vendor_search_server import search_vendors

    # This will return empty or error if vector store is not initialized
    results = search_vendors("Python development expertise", top_k=5)
    assert isinstance(results, list)

def test_compliance_check_tool():
    """Test compliance check tool"""
    from app.mcp_servers.compliance_server import check_vendor_compliance

    tender_data = {
        "requirements": "ISO 9001 certified, 10+ years experience"
    }

    vendor_data = {
        "certifications": ["ISO 9001", "ISO 27001"],
        "years_experience": 15
    }

    result = check_vendor_compliance(tender_data, vendor_data)
    assert result["status"] == "success"
    assert "compliance_check" in result

def test_vector_store_initialization():
    """Test FAISS vector store initialization"""
    from app.services.vector_store import TenderVectorStore

    vs = TenderVectorStore()
    vs.initialize_store()
    assert vs.vector_store is not None

def test_llm_service():
    """Test LLM service initialization"""
    from app.services.llm_service import LLMService

    llm = LLMService()
    assert llm.llm is not None
