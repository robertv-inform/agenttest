import os
import sys
from typing import TypedDict, Annotated, Sequence
from langchain_openai import ChatOpenAI
from langchain_core.messages import BaseMessage, HumanMessage, SystemMessage
from langgraph.graph import StateGraph, END
from langgraph.prebuilt import ToolExecutor
from langchain_core.tools import tool
import requests
import json

# ==================== STATE DEFINITION ====================

class AgentState(TypedDict):
    """State for candidate evaluation workflow"""
    candidate_id: str
    job_role: str
    source_certificates: list[str]
    target_certificates: list[str]

    # Workflow state
    api_status: dict
    embedding_prefilter_result: dict
    gpt4o_result: dict
    final_recommendation: dict

    # Messages for LangGraph
    messages: Annotated[Sequence[BaseMessage], "messages"]

    # Decision flags
    use_embeddings: bool
    requires_human_review: bool
    processing_complete: bool

# ==================== TOOLS (MCP-like, but LangChain native) ====================

API_BASE_URL = "http://127.0.0.1:8000"

@tool
def check_api_status() -> dict:
    """Check if Matching API is running and healthy"""
    try:
        response = requests.get(f"{API_BASE_URL}/health", timeout=5)
        return response.json()
    except:
        return {"status": "unavailable", "error": "API not responding"}

@tool
def match_certificates_with_embeddings(
    candidate_id: str,
    job_role: str,
    source_certificates: list[str],
    target_certificates: list[str]
) -> dict:
    """Match certificates using embedding + GPT-4o hybrid approach"""
    try:
        payload = {
            "candidate_id": candidate_id,
            "job_role": job_role,
            "source_certificates": source_certificates,
            "target_certificates": target_certificates,
            "use_embeddings": True
        }

        response = requests.post(
            f"{API_BASE_URL}/match",
            json=payload,
            timeout=30
        )

        response.raise_for_status()
        return response.json()

    except Exception as e:
        return {"error": str(e), "status": "failed"}

# ==================== WORKFLOW NODES ====================

def check_api_node(state: AgentState) -> AgentState:
    """Node 1: Check if API is available"""
    print("\n🔍 [Node 1] Checking API status...")

    status = check_api_status.invoke({})
    state["api_status"] = status

    if status.get("status") == "healthy":
        print("✅ API is healthy")
        state["messages"].append(
            SystemMessage(content=f"API Status: {json.dumps(status)}")
        )
    else:
        print("❌ API unavailable")
        state["processing_complete"] = True
        state["final_recommendation"] = {
            "error": "API not available",
            "recommendation": "Cannot process - API offline"
        }

    return state

def match_certificates_node(state: AgentState) -> AgentState:
    """Node 2: Match certificates using API"""
    print(f"\n🎯 [Node 2] Matching certificates for {state['candidate_id']}...")

    result = match_certificates_with_embeddings.invoke({
        "candidate_id": state["candidate_id"],
        "job_role": state["job_role"],
        "source_certificates": state["source_certificates"],
        "target_certificates": state["target_certificates"]
    })

    state["gpt4o_result"] = result

    print(f"📊 Match Score: {result.get('matching_score', 0)}%")
    print(f"🔧 Processing Method: {result.get('processing_method', 'unknown')}")

    if result.get("embedding_similarity"):
        print(f"📈 Embedding Similarity: {result['embedding_similarity']:.3f}")

    state["messages"].append(
        SystemMessage(content=f"Match Result: {json.dumps(result, indent=2)}")
    )

    return state

def evaluate_decision_node(state: AgentState) -> AgentState:
    """Node 3: Decide if human review needed"""
    print("\n🤔 [Node 3] Evaluating decision...")

    result = state.get("gpt4o_result", {})
    score = result.get("matching_score", 0)

    # Business rules for human review
    if score >= 80:
        state["requires_human_review"] = False
        print("✅ Auto-approve (score >= 80)")
    elif score < 40:
        state["requires_human_review"] = False
        print("❌ Auto-reject (score < 40)")
    else:
        state["requires_human_review"] = True
        print("⚠️  Human review required (40 <= score < 80)")

    return state

def format_recommendation_node(state: AgentState) -> AgentState:
    """Node 4: Format final recommendation for user"""
    print("\n📝 [Node 4] Formatting recommendation...")

    result = state.get("gpt4o_result", {})

    recommendation = {
        "candidate_id": state["candidate_id"],
        "job_role": state["job_role"],
        "matching_score": result.get("matching_score", 0),
        "recommendation": result.get("recommendation", "Unknown"),
        "matched_certificates": result.get("matched_certificates", []),
        "missing_certificates": result.get("missing_certificates", []),
        "explanation": result.get("explanation", ""),
        "processing_method": result.get("processing_method", "unknown"),
        "requires_human_review": state["requires_human_review"]
    }

    state["final_recommendation"] = recommendation
    state["processing_complete"] = True

    return state

# ==================== ROUTING LOGIC ====================

def should_continue(state: AgentState) -> str:
    """Decide next step based on state"""

    if not state.get("api_status", {}).get("status") == "healthy":
        return "end"

    if state.get("processing_complete"):
        return "end"

    # Workflow progression
    if "api_status" in state and "gpt4o_result" not in state:
        return "match"

    if "gpt4o_result" in state and "final_recommendation" not in state:
        return "evaluate"

    return "end"

# ==================== BUILD LANGGRAPH ====================

def create_agent_graph():
    """Create LangGraph workflow"""

    workflow = StateGraph(AgentState)

    # Add nodes
    workflow.add_node("check_api", check_api_node)
    workflow.add_node("match", match_certificates_node)
    workflow.add_node("evaluate", evaluate_decision_node)
    workflow.add_node("format", format_recommendation_node)

    # Define edges
    workflow.set_entry_point("check_api")

    workflow.add_conditional_edges(
        "check_api",
        should_continue,
        {
            "match": "match",
            "end": END
        }
    )

    workflow.add_edge("match", "evaluate")
    workflow.add_edge("evaluate", "format")
    workflow.add_edge("format", END)

    return workflow.compile()

# ==================== MAIN EXECUTION ====================

def evaluate_candidate(
    candidate_id: str,
    job_role: str,
    source_certificates: list[str],
    target_certificates: list[str]
):
    """Evaluate a candidate using LangGraph workflow"""

    print("="*80)
    print("CERTIFICATE MATCHING - LANGGRAPH PRODUCTION EDITION")
    print("Agent → LangGraph State Machine → MCP-style Tools → API → GPT-4o")
    print("="*80)

    # Initialize state
    initial_state = AgentState(
        candidate_id=candidate_id,
        job_role=job_role,
        source_certificates=source_certificates,
        target_certificates=target_certificates,
        api_status={},
        embedding_prefilter_result={},
        gpt4o_result={},
        final_recommendation={},
        messages=[],
        use_embeddings=True,
        requires_human_review=False,
        processing_complete=False
    )

    # Create and run graph
    app = create_agent_graph()

    print("\n🚀 Starting evaluation workflow...\n")

    final_state = app.invoke(initial_state)

    # Print results
    print("\n" + "="*80)
    print("EVALUATION RESULT")
    print("="*80)

    recommendation = final_state.get("final_recommendation", {})

    if "error" in recommendation:
        print(f"❌ Error: {recommendation['error']}")
        return

    print(f"\n📋 Candidate: {recommendation['candidate_id']}")
    print(f"💼 Job Role: {recommendation['job_role']}")
    print(f"📊 Matching Score: {recommendation['matching_score']}%")
    print(f"🎯 Recommendation: {recommendation['recommendation']}")
    print(f"🔧 Processing Method: {recommendation['processing_method']}")

    if recommendation.get("requires_human_review"):
        print(f"⚠️  HUMAN REVIEW REQUIRED")
    else:
        print(f"✅ AUTO-PROCESSED")

    print(f"\n✅ Matched Certificates ({len(recommendation['matched_certificates'])}):")
    for cert in recommendation['matched_certificates']:
        print(f"   • {cert}")

    print(f"\n❌ Missing Certificates ({len(recommendation['missing_certificates'])}):")
    for cert in recommendation['missing_certificates']:
        print(f"   • {cert}")

    print(f"\n💡 Explanation:")
    print(f"   {recommendation['explanation']}")

    print("\n" + "="*80 + "\n")

if __name__ == "__main__":
    # Example usage
    evaluate_candidate(
        candidate_id="CAND_2025_001",
        job_role="Senior Data Scientist",
        source_certificates=[
            "AWS Certified Solutions Architect - Professional",
            "Azure Data Engineer Associate",
            "Google Cloud Professional Data Engineer",
            "TensorFlow Developer Certificate"
        ],
        target_certificates=[
            "AWS Certified Solutions Architect",
            "Azure Data Engineer",
            "Kubernetes Administrator",
            "Machine Learning Specialization"
        ]
    )
