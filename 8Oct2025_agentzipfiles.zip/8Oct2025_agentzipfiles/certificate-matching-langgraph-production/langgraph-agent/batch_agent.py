import os
import sys
import json
import csv
from datetime import datetime
import random
from agent import create_agent_graph, AgentState
from langchain_core.messages import SystemMessage

def generate_candidates(num=100):
    """Generate sample candidate data"""

    job_roles = {
        "Senior Data Scientist": ["AWS Solutions Architect", "Azure Data Engineer", "TensorFlow Developer"],
        "ML Engineer": ["TensorFlow Developer", "Python for Data Science", "Kubernetes Admin"],
        "Cloud Architect": ["AWS Solutions Architect", "Azure Solutions Architect", "GCP Professional"],
        "DevOps Engineer": ["Kubernetes Admin", "Docker Certified", "AWS Solutions Architect"],
        "Full Stack Developer": ["Python for Data Science", "Docker Certified", "Scrum Master"]
    }

    cert_pool = [
        "AWS Solutions Architect", "Azure Data Engineer", "GCP Professional",
        "Scrum Master", "PMP", "TensorFlow Developer", "Kubernetes Admin",
        "Python for Data Science", "Deep Learning Specialization", "Docker Certified"
    ]

    candidates = []
    for i in range(1, num + 1):
        job_role = random.choice(list(job_roles.keys()))
        num_certs = random.randint(2, 6)
        source_certs = random.sample(cert_pool, num_certs)

        candidates.append({
            "candidate_id": f"CAND_{i:04d}",
            "job_role": job_role,
            "source_certificates": source_certs,
            "target_certificates": job_roles[job_role]
        })

    return candidates

def process_batch_langgraph(candidates, batch_size=50):
    """Process candidates in batches using LangGraph"""

    print("\n" + "="*80)
    print(f"BATCH PROCESSING - LANGGRAPH PRODUCTION EDITION")
    print(f"Processing {len(candidates)} candidates")
    print("="*80 + "\n")

    # Create compiled graph once (reuse for efficiency)
    app = create_agent_graph()

    all_results = []
    start_time = datetime.now()

    total_batches = (len(candidates) + batch_size - 1) // batch_size

    for batch_num in range(0, len(candidates), batch_size):
        batch = candidates[batch_num:batch_num + batch_size]
        current_batch = (batch_num // batch_size) + 1

        print(f"\n📦 Processing Batch {current_batch}/{total_batches} ({len(batch)} candidates)...")

        batch_results = []

        for candidate in batch:
            try:
                # Create initial state
                initial_state = AgentState(
                    candidate_id=candidate["candidate_id"],
                    job_role=candidate["job_role"],
                    source_certificates=candidate["source_certificates"],
                    target_certificates=candidate["target_certificates"],
                    api_status={},
                    embedding_prefilter_result={},
                    gpt4o_result={},
                    final_recommendation={},
                    messages=[],
                    use_embeddings=True,
                    requires_human_review=False,
                    processing_complete=False
                )

                # Run workflow
                final_state = app.invoke(initial_state)

                # Extract recommendation
                recommendation = final_state.get("final_recommendation", {})

                if "error" not in recommendation:
                    batch_results.append(recommendation)
                    all_results.append(recommendation)

            except Exception as e:
                print(f"   ❌ Error processing {candidate['candidate_id']}: {e}")

        print(f"✅ Batch {current_batch} completed: {len(batch_results)} successful\n")

    end_time = datetime.now()
    duration = (end_time - start_time).total_seconds()

    # Save results
    output_file = f"langgraph_results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"

    with open(output_file, 'w', newline='', encoding='utf-8') as f:
        fieldnames = [
            'candidate_id', 'job_role', 'matching_score', 'recommendation',
            'matched_certs', 'missing_certs', 'processing_method', 'human_review_required'
        ]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()

        for result in all_results:
            row = {
                'candidate_id': result.get('candidate_id', 'N/A'),
                'job_role': result.get('job_role', 'N/A'),
                'matching_score': result.get('matching_score', 0),
                'recommendation': result.get('recommendation', 'N/A'),
                'matched_certs': '|'.join(result.get('matched_certificates', [])),
                'missing_certs': '|'.join(result.get('missing_certificates', [])),
                'processing_method': result.get('processing_method', 'unknown'),
                'human_review_required': result.get('requires_human_review', False)
            }
            writer.writerow(row)

    # Statistics
    total_processed = len(all_results)
    auto_processed = len([r for r in all_results if not r.get('requires_human_review')])
    human_review = len([r for r in all_results if r.get('requires_human_review')])
    embedding_only = len([r for r in all_results if r.get('processing_method') == 'embedding_only'])
    hybrid_gpt4o = len([r for r in all_results if r.get('processing_method') == 'hybrid_gpt4o'])

    print("\n" + "="*80)
    print("BATCH PROCESSING COMPLETE")
    print("="*80)
    print(f"Total candidates: {len(candidates)}")
    print(f"Successfully processed: {total_processed}")
    print(f"Duration: {duration:.1f} seconds")
    print(f"Avg per candidate: {duration/len(candidates):.2f}s")
    print(f"\nProcessing Breakdown:")
    print(f"  • Auto-processed: {auto_processed} ({auto_processed/total_processed*100:.1f}%)")
    print(f"  • Human review required: {human_review} ({human_review/total_processed*100:.1f}%)")
    print(f"  • Embedding-only (no GPT-4o): {embedding_only} ({embedding_only/total_processed*100:.1f}%)")
    print(f"  • Hybrid (embedding + GPT-4o): {hybrid_gpt4o} ({hybrid_gpt4o/total_processed*100:.1f}%)")
    print(f"\n💰 Cost Savings:")
    print(f"  Embedding-only processing saved ~{embedding_only * 0.002:.2f} USD")
    print(f"  (Avoided {embedding_only} GPT-4o calls)")
    print(f"\nResults saved: {output_file}")
    print("="*80 + "\n")

def main():
    num = 100

    if len(sys.argv) > 1:
        try:
            num = int(sys.argv[1])
        except:
            pass

    print("\n🎯 Certificate Matching - LangGraph Batch Processing")
    print("="*80)
    print(f"\nUsage: python batch_agent.py [NUM_CANDIDATES]")
    print(f"Processing: {num} candidates\n")

    print(f"📊 Generating {num} candidates...")
    candidates = generate_candidates(num)
    print(f"✅ Generated {len(candidates)} candidates\n")

    process_batch_langgraph(candidates, batch_size=50)

if __name__ == "__main__":
    main()
