from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Dict, Optional
import os
import json
import logging
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity

# Import OpenAI
try:
    from openai import OpenAI
    OPENAI_AVAILABLE = True
except ImportError:
    OPENAI_AVAILABLE = False

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="Certificate Matching API - LangGraph Edition")

# Initialize OpenAI client
openai_client = None
if OPENAI_AVAILABLE and os.getenv("OPENAI_API_KEY"):
    openai_client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

class MatchRequest(BaseModel):
    candidate_id: str
    job_role: str
    source_certificates: List[str]
    target_certificates: List[str]
    use_embeddings: bool = True  # New: Cost optimization flag

class MatchResponse(BaseModel):
    candidate_id: str
    job_role: str
    matching_score: float
    matched_certificates: List[str]
    missing_certificates: List[str]
    additional_certificates: List[str]
    recommendation: str
    explanation: str
    source: str
    embedding_similarity: Optional[float] = None
    processing_method: str  # "embedding_only", "gpt4o_only", "hybrid"

class EmbeddingMatchResult(BaseModel):
    similarity_score: float
    should_use_gpt4o: bool
    reason: str

# ==================== EMBEDDING-BASED PRE-FILTERING ====================

def get_embeddings(texts: List[str]) -> np.ndarray:
    """Get embeddings using OpenAI text-embedding-3-large"""
    if not openai_client:
        logger.warning("OpenAI not available, using mock embeddings")
        return np.random.rand(len(texts), 1536)

    try:
        response = openai_client.embeddings.create(
            model="text-embedding-3-large",
            input=texts
        )
        embeddings = [item.embedding for item in response.data]
        return np.array(embeddings)
    except Exception as e:
        logger.error(f"Embedding error: {e}")
        return np.random.rand(len(texts), 1536)

def embedding_similarity_match(source_certs: List[str], target_certs: List[str]) -> EmbeddingMatchResult:
    """Quick similarity check using embeddings (cheap)"""

    # Concatenate certificates into strings
    source_text = ", ".join(source_certs)
    target_text = ", ".join(target_certs)

    # Get embeddings
    embeddings = get_embeddings([source_text, target_text])

    # Calculate cosine similarity
    similarity = cosine_similarity([embeddings[0]], [embeddings[1]])[0][0]

    logger.info(f"Embedding similarity: {similarity:.3f}")

    # Decision logic: Use GPT-4o only if needed
    if similarity > 0.85:
        return EmbeddingMatchResult(
            similarity_score=float(similarity),
            should_use_gpt4o=False,
            reason="High similarity (>0.85), simple match sufficient"
        )
    elif similarity < 0.5:
        return EmbeddingMatchResult(
            similarity_score=float(similarity),
            should_use_gpt4o=False,
            reason="Low similarity (<0.5), likely poor match"
        )
    else:
        return EmbeddingMatchResult(
            similarity_score=float(similarity),
            should_use_gpt4o=True,
            reason="Moderate similarity (0.5-0.85), need GPT-4o analysis"
        )

# ==================== MOCK MATCHING ====================

def mock_match(request: MatchRequest) -> MatchResponse:
    """Simple rule-based matching"""
    source_set = set(request.source_certificates)
    target_set = set(request.target_certificates)

    matched = list(source_set & target_set)
    missing = list(target_set - source_set)
    additional = list(source_set - target_set)

    score = (len(matched) / len(target_set) * 100) if target_set else 0

    if score >= 80:
        recommendation = "Strong Match"
    elif score >= 60:
        recommendation = "Good Match"
    elif score >= 40:
        recommendation = "Partial Match"
    else:
        recommendation = "Poor Match"

    return MatchResponse(
        candidate_id=request.candidate_id,
        job_role=request.job_role,
        matching_score=round(score, 1),
        matched_certificates=matched,
        missing_certificates=missing,
        additional_certificates=additional,
        recommendation=recommendation,
        explanation=f"Mock: {len(matched)}/{len(target_set)} certs matched",
        source="mock",
        processing_method="mock"
    )

# ==================== GPT-4O MATCHING ====================

def gpt4o_match(request: MatchRequest) -> MatchResponse:
    """Intelligent matching with GPT-4o"""

    if not openai_client:
        raise ValueError("OpenAI client not initialized")

    prompt = f"""You are an expert HR analyst. Analyze certificate matching:

Job Role: {request.job_role}
Candidate ID: {request.candidate_id}

Required Certificates (Target):
{chr(10).join(f"- {cert}" for cert in request.target_certificates)}

Candidate Certificates (Source):
{chr(10).join(f"- {cert}" for cert in request.source_certificates)}

Analyze and return JSON:
{{
  "matching_score": <float 0-100>,
  "matched_certificates": [<list with reasoning>],
  "missing_certificates": [<list>],
  "additional_certificates": [<list>],
  "recommendation": "<Strong Match|Good Match|Partial Match|Poor Match>",
  "explanation": "<detailed explanation>"
}}

Consider:
- Exact matches
- Equivalent certificates (AWS ≈ Azure ≈ GCP)
- Hierarchy (Professional > Associate > Fundamentals)
- Domain relevance"""

    try:
        response = openai_client.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": "Expert HR analyst. Return only valid JSON."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.3,
            max_tokens=800
        )

        result_text = response.choices[0].message.content.strip()

        # Clean markdown
        if result_text.startswith("```"):
            result_text = result_text.split("```")[1]
            if result_text.startswith("json"):
                result_text = result_text[4:]
            result_text = result_text.strip()

        result = json.loads(result_text)

        return MatchResponse(
            candidate_id=request.candidate_id,
            job_role=request.job_role,
            matching_score=result["matching_score"],
            matched_certificates=result["matched_certificates"],
            missing_certificates=result["missing_certificates"],
            additional_certificates=result["additional_certificates"],
            recommendation=result["recommendation"],
            explanation=result["explanation"],
            source="gpt-4o",
            processing_method="gpt4o_only"
        )

    except Exception as e:
        logger.error(f"GPT-4o error: {e}")
        raise

# ==================== HYBRID MATCHING (Embeddings + GPT-4o) ====================

def hybrid_match(request: MatchRequest) -> MatchResponse:
    """Cost-optimized hybrid: Embeddings pre-filter → GPT-4o for complex cases"""

    logger.info(f"Hybrid matching for {request.candidate_id}")

    # Step 1: Quick embedding similarity check
    embedding_result = embedding_similarity_match(
        request.source_certificates,
        request.target_certificates
    )

    logger.info(f"Embedding decision: {embedding_result.reason}")

    # Step 2: Decide whether to use GPT-4o
    if not embedding_result.should_use_gpt4o:
        # Use simple matching (no GPT-4o cost)
        result = mock_match(request)
        result.embedding_similarity = embedding_result.similarity_score
        result.processing_method = "embedding_only"
        result.explanation += f" | Embedding similarity: {embedding_result.similarity_score:.2f}"
        return result
    else:
        # Use GPT-4o for nuanced analysis
        result = gpt4o_match(request)
        result.embedding_similarity = embedding_result.similarity_score
        result.processing_method = "hybrid_gpt4o"
        result.explanation += f" | Pre-filtered by embeddings ({embedding_result.similarity_score:.2f})"
        return result

# ==================== API ENDPOINTS ====================

@app.post("/match", response_model=MatchResponse)
async def match_certificates(request: MatchRequest):
    """Match certificates with embeddings + GPT-4o hybrid approach"""

    logger.info(f"Match request for {request.candidate_id}, embeddings={request.use_embeddings}")

    try:
        if not OPENAI_AVAILABLE or not openai_client:
            logger.warning("OpenAI unavailable, using mock")
            return mock_match(request)

        if request.use_embeddings:
            # Hybrid: Embeddings → GPT-4o (cost-optimized)
            return hybrid_match(request)
        else:
            # Direct GPT-4o (no pre-filtering)
            return gpt4o_match(request)

    except Exception as e:
        logger.error(f"Match error: {e}, falling back to mock")
        result = mock_match(request)
        result.explanation += f" (Fallback: {str(e)})"
        return result

@app.get("/health")
async def health_check():
    """Health check"""
    return {
        "status": "healthy",
        "openai_available": OPENAI_AVAILABLE and openai_client is not None,
        "api_key_set": bool(os.getenv("OPENAI_API_KEY")),
        "embeddings_enabled": True
    }

@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "service": "Certificate Matching API - LangGraph Edition",
        "version": "2.0",
        "features": [
            "Embedding-based pre-filtering",
            "GPT-4o intelligent matching",
            "Hybrid cost optimization",
            "Mock fallback"
        ],
        "endpoints": ["/match", "/health"]
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
