from mcp.server.fastmcp import FastMCP
import json
import requests
from typing import List, Dict
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

mcp = FastMCP("certificate-matcher-langgraph")

API_BASE_URL = "http://127.0.0.1:8000"

@mcp.tool()
def MatchCertificates(
    candidate_id: str,
    job_role: str,
    source_certificates: List[str],
    target_certificates: List[str],
    use_embeddings: bool = True
) -> str:
    """Match candidate certificates using embeddings + GPT-4o hybrid approach.

    Args:
        candidate_id: Unique candidate identifier
        job_role: Target job role
        source_certificates: Candidate's certificates
        target_certificates: Required certificates
        use_embeddings: Use cost-optimized embedding pre-filtering (default: True)

    Returns:
        JSON with matching results including score, matched/missing certs, recommendation
    """
    try:
        payload = {
            "candidate_id": candidate_id,
            "job_role": job_role,
            "source_certificates": source_certificates,
            "target_certificates": target_certificates,
            "use_embeddings": use_embeddings
        }

        response = requests.post(
            f"{API_BASE_URL}/match",
            json=payload,
            timeout=30
        )

        response.raise_for_status()
        result = response.json()

        logger.info(f"Match: {result.get('matching_score')}%, method: {result.get('processing_method')}")

        return json.dumps(result, indent=2)

    except requests.exceptions.ConnectionError:
        return json.dumps({
            "error": "API not available",
            "hint": "Start API: cd matching-api && python api.py"
        }, indent=2)

    except Exception as e:
        return json.dumps({"error": str(e)}, indent=2)

@mcp.tool()
def CheckAPIStatus() -> str:
    """Check if Matching API is running"""
    try:
        response = requests.get(f"{API_BASE_URL}/health", timeout=5)
        return json.dumps(response.json(), indent=2)
    except:
        return json.dumps({
            "status": "unavailable",
            "message": "API not running"
        }, indent=2)

if __name__ == "__main__":
    mcp.run(transport="stdio")
