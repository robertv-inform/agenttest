# Certificate Matching System V1 - Production Architecture

Complete enterprise-grade certificate matching system with proper separation of concerns.

## 🏗️ Architecture

```
┌─────────────┐
│   User      │
└──────┬──────┘
       │
       ▼
┌─────────────────────────────────────────┐
│         CrewAI Agent (HR Analyst)       │
│  • Understands context                  │
│  • Reasoning & planning                 │
│  • Presents results to user             │
└──────────────┬──────────────────────────┘
               │
               ▼
┌─────────────────────────────────────────┐
│          MCP Server (Tool Layer)        │
│  • MatchCertificates()                  │
│  • BatchMatchCertificates()             │
│  • CheckAPIStatus()                     │
│  • Thin wrapper to API                  │
└──────────────┬──────────────────────────┘
               │
               ▼
┌─────────────────────────────────────────┐
│    Matching API (Business Logic)       │
│  • FastAPI REST endpoints               │
│  • GPT-4o integration                   │
│  • Mock fallback                        │
│  • Caching ready                        │
│  • Enterprise features                  │
└──────────────┬──────────────────────────┘
               │
               ▼
┌─────────────────────────────────────────┐
│         OpenAI GPT-4o API               │
│  • Intelligent matching                 │
│  • Equivalency detection                │
│  • Context understanding                │
└─────────────────────────────────────────┘
```

## 📦 Components

### 1. Matching API (`matching-api/`)
FastAPI service providing certificate matching logic.

**Endpoints**:
- `POST /match` - Match single candidate
- `POST /batch-match` - Batch matching
- `GET /health` - Health check
- `GET /` - API info

**Features**:
- GPT-4o integration
- Automatic mock fallback
- Independent of MCP
- Can be called directly from any client

### 2. MCP Server (`mcp-server/`)
Thin wrapper exposing API as MCP tools.

**Tools**:
- `MatchCertificates()` - Single match
- `BatchMatchCertificates()` - Batch match
- `CheckAPIStatus()` - Verify API connection

**Features**:
- Protocol-compliant MCP tools
- Connection health checks
- Error handling

### 3. CrewAI Agents (`crewai-agent/`)
Intelligent agents using MCP tools.

**Scripts**:
- `single_candidate.py` - Evaluate one candidate
- `batch_processing.py` - Process 100-1000 candidates

## 🚀 Quick Start

### Step 1: Setup

```bash
# Extract package
unzip certificate-matching-v1-final.zip
cd certificate-matching-v1-final

# Setup all environments
chmod +x setup.sh
./setup.sh
```

### Step 2: Start Matching API

Terminal 1:
```bash
conda activate matching-api-env
cd matching-api
python api.py
```

Wait for: `Uvicorn running on http://0.0.0.0:8000`

### Step 3: Test API (Optional)

Terminal 2:
```bash
conda activate matching-api-env
python test_api.py
```

### Step 4: Run Agent

Terminal 2 (or 3):
```bash
conda activate crewai-env
cd crewai-agent

# Single candidate
python single_candidate.py

# Batch processing
python batch_processing.py 100
```

## 🧪 Testing Flow

### 1. Test API Directly
```bash
# Health check
curl http://localhost:8000/health

# Match request
curl -X POST http://localhost:8000/match \
  -H "Content-Type: application/json" \
  -d '{
    "candidate_id": "TEST_001",
    "job_role": "Data Scientist",
    "source_certificates": ["AWS", "Azure"],
    "target_certificates": ["AWS", "GCP"]
  }'
```

### 2. Test MCP Server
```bash
conda activate mcp-env
python test_mcp.py
```

### 3. Test Full Flow (Agent → MCP → API → GPT-4o)
```bash
conda activate crewai-env
cd crewai-agent
python single_candidate.py
```

## 🎭 Modes

### Mock Mode (Default)
No OpenAI API key needed. Uses simple matching logic.

```bash
# Don't set OPENAI_API_KEY
python api.py  # API uses mock
```

### GPT-4o Mode (Production)
Requires OpenAI API key for intelligent matching.

```bash
export OPENAI_API_KEY='your-key-here'
python api.py  # API uses GPT-4o
```

## 📊 End-to-End Flow Example

### Request Flow:
```
1. User asks agent to evaluate candidate
   ↓
2. Agent receives task and plans approach
   ↓
3. Agent calls MCP tool: MatchCertificates(candidate_data)
   ↓
4. MCP server forwards request to Matching API
   ↓
5. Matching API calls GPT-4o (or uses mock)
   ↓
6. GPT-4o analyzes and returns intelligent match
   ↓
7. API formats response and returns to MCP
   ↓
8. MCP returns result to Agent
   ↓
9. Agent interprets result and presents to user
```

### Data Flow:
```json
// Step 3: Agent → MCP
{
  "candidate_id": "CAND_001",
  "job_role": "Data Scientist",
  "source_certificates": ["AWS Pro", "Azure"],
  "target_certificates": ["AWS", "GCP"]
}

// Step 4: MCP → API (same data)

// Step 5-6: API → GPT-4o → API
{
  "matching_score": 85.0,
  "matched_certificates": ["AWS (Professional exceeds requirement)"],
  "missing_certificates": ["GCP"],
  "recommendation": "Strong Match",
  "source": "gpt-4o"
}

// Step 7-8: API → MCP → Agent (same result)

// Step 9: Agent → User
"Analysis complete! Candidate has 85% match score.
AWS Professional certification exceeds required Associate level.
Missing: Google Cloud Professional.
Recommendation: Strong Match - Proceed to interview."
```

## 💡 Why This Architecture?

### Benefits:

✅ **Separation of Concerns**
- MCP = Tool interface
- API = Business logic  
- GPT-4o = AI intelligence

✅ **Reusability**
```python
# Multiple clients can use API
MCP → API
Web UI → API
Mobile → API
Batch Jobs → API
SAP Integration → API
```

✅ **Independent Scaling**
- Scale API independently
- Load balance across multiple API instances
- MCP servers can be lightweight

✅ **Easy Testing**
- Test API without MCP
- Test MCP without Agent
- Test each layer independently

✅ **Enterprise Ready**
- Add Redis caching at API level
- Rate limiting per client
- API versioning (v1, v2)
- Monitoring & metrics
- A/B testing different LLMs

## 🔧 Configuration

### Matching API (`matching-api/api.py`)

**Change GPT Model**:
```python
model="gpt-4o-mini"  # Lower cost
model="gpt-4o"       # Best quality
```

**Add Caching**:
```python
# Add Redis
import redis
cache = redis.Redis(host='localhost', port=6379)

# Check cache before GPT-4o
cache_key = f"{candidate_id}:{job_role}"
if cache.exists(cache_key):
    return cache.get(cache_key)
```

**Rate Limiting**:
```python
from slowapi import Limiter

limiter = Limiter(key_func=get_remote_address)
app.state.limiter = limiter

@app.post("/match")
@limiter.limit("100/minute")
async def match_certificates(...):
    ...
```

### MCP Server (`mcp-server/server.py`)

**Change API URL**:
```python
API_BASE_URL = "https://your-api.company.com"
```

**Increase Timeout**:
```python
API_TIMEOUT = 60  # For slow networks
```

## 📈 Scaling

### Horizontal Scaling:
```bash
# Run multiple API instances
python api.py --port 8000  # Instance 1
python api.py --port 8001  # Instance 2
python api.py --port 8002  # Instance 3

# Use nginx for load balancing
upstream matching_api {
    server 127.0.0.1:8000;
    server 127.0.0.1:8001;
    server 127.0.0.1:8002;
}
```

### Docker Deployment:
```dockerfile
# Dockerfile for API
FROM python:3.11
COPY matching-api /app
RUN pip install -r requirements.txt
CMD ["python", "api.py"]
```

## 🐛 Troubleshooting

**Problem**: API not starting
```bash
# Check port
lsof -i :8000

# Use different port
python api.py --port 8001
```

**Problem**: MCP can't connect to API
```bash
# Verify API is running
curl http://localhost:8000/health

# Check MCP server logs
# Look for "API is not responding" error
```

**Problem**: Mock always used
```bash
# Set API key
export OPENAI_API_KEY='sk-...'

# Verify in API
curl http://localhost:8000/health
# Check "api_key_set": true
```

## 📊 File Structure

```
certificate-matching-v1-final/
├── matching-api/           # FastAPI service
│   ├── api.py             # Main API server
│   └── requirements.txt
├── mcp-server/            # MCP tool layer
│   ├── server.py          # MCP tools
│   └── requirements.txt
├── crewai-agent/          # AI agents
│   ├── single_candidate.py
│   ├── batch_processing.py
│   └── requirements.txt
├── test_api.py            # Test API directly
├── test_mcp.py            # Test MCP tools
├── setup.sh               # Setup all envs
└── README.md              # This file
```

## 🎯 Production Checklist

Before deploying to production:

- [ ] Set up Redis caching
- [ ] Add rate limiting
- [ ] Configure load balancing
- [ ] Set up monitoring (Prometheus/Grafana)
- [ ] Add authentication to API
- [ ] Use HTTPS
- [ ] Set up logging aggregation
- [ ] Configure auto-scaling
- [ ] Add health check endpoints
- [ ] Set up CI/CD pipeline

## 💰 Cost Optimization

**Development**: Use mock mode ($0)
**Testing**: Small batches with GPT-4o (~$0.10)
**Production**: Full GPT-4o with caching

## 📚 Resources

- OpenAI GPT-4o: https://platform.openai.com/docs/models/gpt-4o
- FastAPI: https://fastapi.tiangolo.com/
- MCP: https://modelcontextprotocol.io/
- CrewAI: https://docs.crewai.com/

## 🎉 Ready to Deploy!

Start all components and process 1000 candidates:

```bash
# Terminal 1
conda activate matching-api-env
cd matching-api
python api.py

# Terminal 2
conda activate crewai-env
cd crewai-agent
python batch_processing.py 1000
```
