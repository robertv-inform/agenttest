import os
import sys
import json
import csv
from crewai import Agent, Task, Crew
from crewai_tools import MCPServerAdapter
from mcp import StdioServerParameters
from datetime import datetime
import random

def generate_candidates(num=100):
    """Generate sample candidate data"""

    job_roles = {
        "Senior Data Scientist": ["AWS Solutions Architect", "Azure Data Engineer", "TensorFlow Developer"],
        "ML Engineer": ["TensorFlow Developer", "Python for Data Science", "Kubernetes Admin"],
        "Cloud Architect": ["AWS Solutions Architect", "Azure Solutions Architect", "GCP Professional"],
        "DevOps Engineer": ["Kubernetes Admin", "Docker Certified", "AWS Solutions Architect"],
        "Full Stack Developer": ["Python for Data Science", "Docker Certified", "Scrum Master"]
    }

    cert_pool = [
        "AWS Solutions Architect", "Azure Data Engineer", "GCP Professional",
        "Scrum Master", "PMP", "TensorFlow Developer", "Kubernetes Admin",
        "Python for Data Science", "Deep Learning Specialization", "Docker Certified"
    ]

    candidates = []
    for i in range(1, num + 1):
        job_role = random.choice(list(job_roles.keys()))
        num_certs = random.randint(2, 6)
        source_certs = random.sample(cert_pool, num_certs)

        candidates.append({
            "candidate_id": f"CAND_{i:04d}",
            "job_role": job_role,
            "source_certificates": source_certs,
            "target_certificates": job_roles[job_role]
        })

    return candidates

def process_batch(candidates, batch_size=50):
    """Process candidates in batches"""

    mcp_server_path = os.path.abspath("../mcp-server/server.py")
    conda_python = sys.executable

    print("\n" + "="*80)
    print(f"BATCH PROCESSING - {len(candidates)} CANDIDATES")
    print("Agent → MCP Server → Matching API → GPT-4o")
    print("="*80 + "\n")

    if not os.getenv("OPENAI_API_KEY"):
        print("⚠️  OPENAI_API_KEY not set. Using mock mode.\n")

    server_params = StdioServerParameters(
        command=conda_python,
        args=[mcp_server_path],
        env=os.environ.copy()
    )

    all_results = []
    start_time = datetime.now()

    try:
        with MCPServerAdapter(server_params, connect_timeout=60) as mcp_tools:
            print(f"✅ Connected to MCP. Tools: {len(mcp_tools)}\n")

            total_batches = (len(candidates) + batch_size - 1) // batch_size

            for batch_num in range(0, len(candidates), batch_size):
                batch = candidates[batch_num:batch_num + batch_size]
                current_batch = (batch_num // batch_size) + 1

                print(f"📦 Processing Batch {current_batch}/{total_batches} ({len(batch)} candidates)...")

                # Create agent for batch
                agent = Agent(
                    role=f"Batch Analyst {current_batch}",
                    goal=f"Process {len(batch)} candidates efficiently",
                    backstory="Expert HR analyst for high-volume processing",
                    tools=mcp_tools,
                    verbose=False,
                    allow_delegation=False
                )

                task = Task(
                    description=f"""Process {len(batch)} candidates using BatchMatchCertificates.

First 3 candidates preview:
{json.dumps(batch[:3], indent=2)}

Process all {len(batch)} candidates in this batch.""",
                    expected_output=f"Batch results for {len(batch)} candidates",
                    agent=agent
                )

                crew = Crew(agents=[agent], tasks=[task], verbose=False)
                result = crew.kickoff()

                # Track batch completion
                all_results.extend(batch)
                print(f"✅ Batch {current_batch} completed\n")

            end_time = datetime.now()
            duration = (end_time - start_time).total_seconds()

            # Save results
            output_file = f"results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"

            with open(output_file, 'w', newline='', encoding='utf-8') as f:
                writer = csv.DictWriter(f, fieldnames=[
                    'candidate_id', 'job_role', 'source_certs', 'target_certs'
                ])
                writer.writeheader()

                for result in all_results:
                    row = {
                        'candidate_id': result['candidate_id'],
                        'job_role': result['job_role'],
                        'source_certs': '|'.join(result['source_certificates']),
                        'target_certs': '|'.join(result['target_certificates'])
                    }
                    writer.writerow(row)

            print("="*80)
            print("BATCH COMPLETE")
            print("="*80)
            print(f"Total candidates: {len(candidates)}")
            print(f"Duration: {duration:.1f} seconds")
            print(f"Avg per candidate: {duration/len(candidates):.2f}s")
            print(f"Results saved: {output_file}")
            print("="*80 + "\n")

    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()

def main():
    num = 100

    # Parse command line
    if len(sys.argv) > 1:
        try:
            num = int(sys.argv[1])
        except:
            pass

    print("\n🎯 Certificate Matching - Batch Processing")
    print("="*80)
    print(f"\nUsage: python batch_processing.py [NUM_CANDIDATES]")
    print(f"Processing: {num} candidates\n")

    print(f"📊 Generating {num} candidates...")
    candidates = generate_candidates(num)
    print(f"✅ Generated {len(candidates)} candidates\n")

    process_batch(candidates, batch_size=50)

if __name__ == "__main__":
    main()
