import os
import sys
from crewai import Agent, Task, Crew
from crewai_tools import MCPServerAdapter
from mcp import StdioServerParameters

def evaluate_candidate():
    """Evaluate a single candidate using MCP → API → GPT-4o flow"""

    mcp_server_path = os.path.abspath("../mcp-server/server.py")
    conda_python = sys.executable

    print("="*80)
    print("CERTIFICATE MATCHING - V1 ARCHITECTURE")
    print("Agent → MCP Server → Matching API → GPT-4o")
    print("="*80)
    print(f"\nPython: {conda_python}")
    print(f"MCP Server: {mcp_server_path}")

    if not os.getenv("OPENAI_API_KEY"):
        print("\n⚠️  OPENAI_API_KEY not set. API will use mock mode.\n")
    else:
        print("\n✅ OPENAI_API_KEY detected. Will use GPT-4o.\n")

    server_params = StdioServerParameters(
        command=conda_python,
        args=[mcp_server_path],
        env=os.environ.copy()
    )

    try:
        with MCPServerAdapter(server_params, connect_timeout=60) as mcp_tools:
            print(f"✅ Connected to MCP. Available tools: {len(mcp_tools)}\n")

            # Create specialized HR analyst agent
            analyst = Agent(
                role="Senior HR Certificate Analyst",
                goal="Evaluate candidate certificates against job requirements using enterprise matching tools",
                backstory="""You are a senior HR analyst with 15+ years in technical hiring.
                You specialize in certificate evaluation and credential verification. You have
                access to enterprise-grade matching tools that use AI to assess equivalencies
                and hierarchies between certifications.""",
                tools=mcp_tools,
                verbose=True,
                allow_delegation=False
            )

            # Create evaluation task
            task = Task(
                description="""Evaluate this candidate for Senior Data Scientist position:

**Candidate**: CAND_2025_001
**Job Role**: Senior Data Scientist

**Required Certificates (Target)**:
- AWS Certified Solutions Architect - Associate
- Microsoft Azure Data Engineer Associate
- Certified ScrumMaster (CSM)
- TensorFlow Developer Certificate

**Candidate Certificates (Source)**:
- AWS Certified Solutions Architect - Professional
- Google Cloud Professional Data Engineer
- Professional Scrum Master I (PSM I)
- Deep Learning Specialization (Coursera)
- Python for Data Science (IBM)

First, use CheckAPIStatus to verify the Matching API is running.
Then use MatchCertificates tool to analyze this candidate.
Provide comprehensive evaluation with hiring recommendation.""",
                expected_output="""Detailed report including:
1. API connection status
2. Overall matching score (0-100)
3. Matched certificates with equivalencies
4. Missing critical certificates
5. Additional valuable certifications
6. Final recommendation (Strong/Good/Partial/Poor Match)
7. Interview focus areas
8. Whether result came from GPT-4o or mock""",
                agent=analyst
            )

            crew = Crew(
                agents=[analyst],
                tasks=[task],
                verbose=True
            )

            print("🚀 Starting evaluation...\n")
            result = crew.kickoff()

            print("\n" + "="*80)
            print("EVALUATION RESULT")
            print("="*80)
            print(result)
            print("="*80 + "\n")

    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    evaluate_candidate()
