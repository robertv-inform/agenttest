from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from typing import List, Dict
import os
import json
import logging

# Try to import OpenAI
try:
    import openai
    OPENAI_AVAILABLE = True
except ImportError:
    OPENAI_AVAILABLE = False

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = FastAPI(title="Certificate Matching API")

class MatchRequest(BaseModel):
    candidate_id: str
    job_role: str
    source_certificates: List[str]
    target_certificates: List[str]

class MatchResponse(BaseModel):
    candidate_id: str
    job_role: str
    matching_score: float
    matched_certificates: List[str]
    missing_certificates: List[str]
    additional_certificates: List[str]
    recommendation: str
    explanation: str
    source: str  # "gpt-4o" or "mock"

def mock_match(request: MatchRequest) -> MatchResponse:
    """Generate mock matching results"""

    source_set = set(request.source_certificates)
    target_set = set(request.target_certificates)

    matched = list(source_set & target_set)
    missing = list(target_set - source_set)
    additional = list(source_set - target_set)

    # Calculate score
    score = (len(matched) / len(target_set) * 100) if target_set else 0

    # Determine recommendation
    if score >= 80:
        recommendation = "Strong Match"
    elif score >= 60:
        recommendation = "Good Match"
    elif score >= 40:
        recommendation = "Partial Match"
    else:
        recommendation = "Poor Match"

    explanation = f"Mock evaluation: {len(matched)}/{len(target_set)} required certificates matched. Score: {score:.1f}%"

    return MatchResponse(
        candidate_id=request.candidate_id,
        job_role=request.job_role,
        matching_score=round(score, 1),
        matched_certificates=matched,
        missing_certificates=missing,
        additional_certificates=additional,
        recommendation=recommendation,
        explanation=explanation,
        source="mock"
    )

def gpt4o_match(request: MatchRequest) -> MatchResponse:
    """Use GPT-4o for intelligent matching"""

    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise ValueError("OPENAI_API_KEY not set")

    openai.api_key = api_key

    prompt = f"""You are an expert HR analyst. Analyze this certificate match:

**Job Role**: {request.job_role}
**Candidate ID**: {request.candidate_id}
**Required Certificates**: {', '.join(request.target_certificates)}
**Candidate Certificates**: {', '.join(request.source_certificates)}

Provide:
1. Matching score (0-100)
2. Matched certificates (including equivalents)
3. Missing certificates
4. Additional certificates
5. Recommendation (Strong Match/Good Match/Partial Match/Poor Match)
6. Brief explanation

Return ONLY valid JSON:
{{
    "matching_score": <float>,
    "matched_certificates": [<list>],
    "missing_certificates": [<list>],
    "additional_certificates": [<list>],
    "recommendation": "<string>",
    "explanation": "<string>"
}}"""

    try:
        response = openai.chat.completions.create(
            model="gpt-4o",
            messages=[
                {"role": "system", "content": "You are an expert HR analyst. Return only valid JSON."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.3,
            max_tokens=800
        )

        result_text = response.choices[0].message.content.strip()

        # Clean markdown if present
        if result_text.startswith("```"):
            result_text = result_text.split("```")[1]
            if result_text.startswith("json"):
                result_text = result_text[4:]
            result_text = result_text.strip()

        result = json.loads(result_text)

        return MatchResponse(
            candidate_id=request.candidate_id,
            job_role=request.job_role,
            matching_score=result["matching_score"],
            matched_certificates=result["matched_certificates"],
            missing_certificates=result["missing_certificates"],
            additional_certificates=result["additional_certificates"],
            recommendation=result["recommendation"],
            explanation=result["explanation"],
            source="gpt-4o"
        )

    except Exception as e:
        logger.error(f"GPT-4o API error: {e}")
        raise

@app.post("/match", response_model=MatchResponse)
async def match_certificates(request: MatchRequest):
    """Match certificates using GPT-4o or mock fallback"""

    logger.info(f"Match request for {request.candidate_id}")

    # Try GPT-4o first
    if OPENAI_AVAILABLE and os.getenv("OPENAI_API_KEY"):
        try:
            result = gpt4o_match(request)
            logger.info(f"GPT-4o match: {result.matching_score}%")
            return result
        except Exception as e:
            logger.warning(f"GPT-4o failed, using mock: {e}")
            result = mock_match(request)
            result.explanation += f" (GPT-4o fallback: {str(e)})"
            return result
    else:
        logger.info("Using mock (API key not set or OpenAI unavailable)")
        return mock_match(request)

@app.post("/batch-match")
async def batch_match_certificates(requests: List[MatchRequest]):
    """Batch process multiple matching requests"""

    results = []
    for req in requests:
        try:
            result = await match_certificates(req)
            results.append(result.dict())
        except Exception as e:
            results.append({
                "candidate_id": req.candidate_id,
                "error": str(e),
                "status": "failed"
            })

    return {
        "total": len(requests),
        "successful": len([r for r in results if "error" not in r]),
        "failed": len([r for r in results if "error" in r]),
        "results": results
    }

@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "openai_available": OPENAI_AVAILABLE,
        "api_key_set": bool(os.getenv("OPENAI_API_KEY"))
    }

@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "service": "Certificate Matching API",
        "version": "1.0",
        "endpoints": ["/match", "/batch-match", "/health"]
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
