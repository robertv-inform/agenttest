from mcp.server.fastmcp import FastMCP
import json
import requests
from typing import List, Dict
import logging
import time

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

mcp = FastMCP("certificate-matcher")

# API Configuration
API_BASE_URL = "http://127.0.0.1:8000"
API_TIMEOUT = 30

def check_api_health():
    """Check if Matching API is running"""
    try:
        response = requests.get(f"{API_BASE_URL}/health", timeout=5)
        return response.status_code == 200
    except:
        return False

@mcp.tool()
def MatchCertificates(
    candidate_id: str,
    job_role: str,
    source_certificates: List[str],
    target_certificates: List[str]
) -> str:
    """Match candidate certificates against job requirements via Matching API.

    This tool sends data to the Matching API which uses GPT-4o for intelligent
    certificate matching with automatic mock fallback.

    Args:
        candidate_id: Unique identifier for the candidate
        job_role: Target job role name
        source_certificates: List of candidate's certificates
        target_certificates: List of required certificates for the job

    Returns:
        str: JSON string with matching results including score, matched/missing certs, 
             recommendation, and source (gpt-4o or mock)

    Example:
        MatchCertificates(
            candidate_id="CAND001",
            job_role="Senior Data Scientist",
            source_certificates=["AWS Solutions Architect", "PMP"],
            target_certificates=["AWS Solutions Architect", "Scrum Master"]
        )
    """
    try:
        payload = {
            "candidate_id": candidate_id,
            "job_role": job_role,
            "source_certificates": source_certificates,
            "target_certificates": target_certificates
        }

        logger.info(f"Matching via API: {candidate_id}")

        # Check API health first
        if not check_api_health():
            raise Exception("Matching API is not responding. Please start the API server.")

        response = requests.post(
            f"{API_BASE_URL}/match",
            headers={
                "Accept": "application/json",
                "Content-Type": "application/json"
            },
            data=json.dumps(payload),
            timeout=API_TIMEOUT
        )

        response.raise_for_status()
        result = response.json()

        logger.info(f"Match result: {result.get('matching_score')}% ({result.get('source')})")

        return json.dumps(result, indent=2)

    except requests.exceptions.ConnectionError:
        error_msg = {
            "error": "Cannot connect to Matching API",
            "message": "Please ensure the Matching API is running on http://127.0.0.1:8000",
            "hint": "Run: cd matching-api && python api.py"
        }
        return json.dumps(error_msg, indent=2)

    except requests.exceptions.Timeout:
        error_msg = {
            "error": "API timeout",
            "message": "The Matching API took too long to respond"
        }
        return json.dumps(error_msg, indent=2)

    except Exception as e:
        logger.error(f"Error in MatchCertificates: {e}")
        error_msg = {
            "error": str(e),
            "candidate_id": candidate_id,
            "job_role": job_role
        }
        return json.dumps(error_msg, indent=2)

@mcp.tool()
def BatchMatchCertificates(candidates: List[Dict]) -> str:
    """Batch match multiple candidates via Matching API.

    Args:
        candidates: List of candidate dictionaries with structure:
            [{{
                "candidate_id": "CAND001",
                "job_role": "Data Scientist",
                "source_certificates": ["AWS", "PMP"],
                "target_certificates": ["AWS", "Azure"]
            }}]

    Returns:
        str: JSON string with batch results
    """
    try:
        logger.info(f"Batch matching {len(candidates)} candidates via API")

        if not check_api_health():
            raise Exception("Matching API is not responding")

        response = requests.post(
            f"{API_BASE_URL}/batch-match",
            headers={
                "Accept": "application/json",
                "Content-Type": "application/json"
            },
            data=json.dumps(candidates),
            timeout=120
        )

        response.raise_for_status()
        result = response.json()

        logger.info(f"Batch completed: {result.get('successful')} successful")

        return json.dumps(result, indent=2)

    except Exception as e:
        logger.error(f"Batch error: {e}")
        return json.dumps({"error": str(e), "status": "failed"})

@mcp.tool()
def CheckAPIStatus() -> str:
    """Check if the Matching API is running and healthy.

    Returns:
        str: JSON with API status information
    """
    try:
        response = requests.get(f"{API_BASE_URL}/health", timeout=5)
        if response.status_code == 200:
            health = response.json()
            return json.dumps({
                "status": "healthy",
                "api_available": True,
                "openai_configured": health.get("api_key_set", False),
                "url": API_BASE_URL
            }, indent=2)
        else:
            return json.dumps({
                "status": "unhealthy",
                "api_available": False,
                "message": f"API returned status {response.status_code}"
            }, indent=2)
    except:
        return json.dumps({
            "status": "unavailable",
            "api_available": False,
            "message": "Cannot connect to Matching API. Please start it first.",
            "hint": "cd matching-api && python api.py"
        }, indent=2)

if __name__ == "__main__":
    mcp.run(transport="stdio")
