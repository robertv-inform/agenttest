#!/bin/bash

echo "======================================"
echo "Certificate Matching V1 - Setup"
echo "Production Architecture"
echo "======================================"
echo ""

# 1. Matching API
echo "📦 Setting up Matching API environment..."
conda create -n matching-api-env python=3.11 -y
eval "$(conda shell.bash hook)"
conda activate matching-api-env
cd matching-api
pip install -r requirements.txt
cd ..
echo "✅ Matching API ready"
echo ""

# 2. MCP Server
echo "📦 Setting up MCP Server environment..."
conda create -n mcp-env python=3.11 -y
conda activate mcp-env
cd mcp-server
conda install -c conda-forge mcp -y
pip install -r requirements.txt
cd ..
echo "✅ MCP Server ready"
echo ""

# 3. CrewAI Agent
echo "📦 Setting up CrewAI Agent environment..."
conda create -n crewai-env python=3.11 -y
conda activate crewai-env
cd crewai-agent
pip install -r requirements.txt
conda install -c conda-forge mcp -y
cd ..
echo "✅ CrewAI Agent ready"
echo ""

echo "======================================"
echo "✅ Setup Complete!"
echo "======================================"
echo ""
echo "🚀 To run the system:"
echo ""
echo "Terminal 1 - Start Matching API:"
echo "  conda activate matching-api-env"
echo "  cd matching-api"
echo "  python api.py"
echo ""
echo "Terminal 2 - Test API:"
echo "  conda activate matching-api-env"
echo "  python test_api.py"
echo ""
echo "Terminal 3 - Run Agent:"
echo "  conda activate crewai-env"
echo "  cd crewai-agent"
echo "  python single_candidate.py"
echo ""
echo "💡 Tip: Set OPENAI_API_KEY for GPT-4o mode"
echo "   export OPENAI_API_KEY='your-key'"
echo ""
