#!/usr/bin/env python3
"""Test the Matching API directly"""

import requests
import json
import sys

API_URL = "http://127.0.0.1:8000"

def test_health():
    """Test API health endpoint"""
    print("\n" + "="*70)
    print("Testing API Health Check")
    print("="*70)

    try:
        response = requests.get(f"{API_URL}/health", timeout=5)
        result = response.json()

        print(f"Status: {result['status']}")
        print(f"OpenAI Available: {result['openai_available']}")
        print(f"API Key Set: {result['api_key_set']}")

        if result['api_key_set']:
            print("\n✅ API is ready for GPT-4o mode")
        else:
            print("\n⚠️  API will use mock mode (OPENAI_API_KEY not set)")

        return True
    except requests.exceptions.ConnectionError:
        print("❌ Cannot connect to API. Is it running?")
        print("   Start it with: cd matching-api && python api.py")
        return False
    except Exception as e:
        print(f"❌ Error: {e}")
        return False

def test_match():
    """Test certificate matching"""
    print("\n" + "="*70)
    print("Testing Certificate Matching")
    print("="*70)

    test_data = {
        "candidate_id": "TEST_001",
        "job_role": "Senior Data Scientist",
        "source_certificates": [
            "AWS Certified Solutions Architect - Professional",
            "Azure Data Engineer Associate",
            "TensorFlow Developer Certificate"
        ],
        "target_certificates": [
            "AWS Certified Solutions Architect",
            "Azure Data Engineer",
            "Kubernetes Administrator"
        ]
    }

    print("\nRequest:")
    print(json.dumps(test_data, indent=2))

    try:
        response = requests.post(
            f"{API_URL}/match",
            json=test_data,
            timeout=30
        )

        if response.status_code == 200:
            result = response.json()

            print("\n" + "-"*70)
            print("Response:")
            print(json.dumps(result, indent=2))

            print("\n" + "="*70)
            print("MATCH SUMMARY")
            print("="*70)
            print(f"Candidate: {result['candidate_id']}")
            print(f"Job Role: {result['job_role']}")
            print(f"Score: {result['matching_score']}%")
            print(f"Recommendation: {result['recommendation']}")
            print(f"Source: {result['source']}")
            print(f"Matched: {len(result['matched_certificates'])} certs")
            print(f"Missing: {len(result['missing_certificates'])} certs")
            print("="*70)

            return True
        else:
            print(f"❌ API returned status {response.status_code}")
            return False

    except Exception as e:
        print(f"❌ Error: {e}")
        return False

def main():
    print("\n🧪 Matching API Test Suite")
    print("="*70)

    # Test 1: Health check
    if not test_health():
        print("\n❌ API is not running. Please start it first.")
        sys.exit(1)

    # Test 2: Certificate matching
    if test_match():
        print("\n✅ All tests passed!")
    else:
        print("\n❌ Some tests failed")
        sys.exit(1)

if __name__ == "__main__":
    main()
