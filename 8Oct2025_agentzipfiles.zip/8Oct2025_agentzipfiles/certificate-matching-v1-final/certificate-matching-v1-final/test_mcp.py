#!/usr/bin/env python3
"""Test MCP server directly"""

import sys
import os

# Add mcp-server to path
sys.path.insert(0, "mcp-server")

def test_mcp():
    """Test MCP tools directly"""
    print("\n" + "="*70)
    print("Testing MCP Server Tools")
    print("="*70)

    try:
        from server import MatchCertificates, CheckAPIStatus

        # Test 1: Check API status
        print("\n📋 Test 1: Check API Status")
        print("-"*70)
        status = CheckAPIStatus()
        print(status)

        # Test 2: Match certificates
        print("\n📋 Test 2: Match Certificates")
        print("-"*70)
        result = MatchCertificates(
            candidate_id="MCP_TEST_001",
            job_role="Data Scientist",
            source_certificates=["AWS", "Azure", "PMP"],
            target_certificates=["AWS", "GCP", "Scrum"]
        )
        print(result)

        print("\n✅ MCP tools working correctly!")

    except Exception as e:
        print(f"❌ Error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    test_mcp()
