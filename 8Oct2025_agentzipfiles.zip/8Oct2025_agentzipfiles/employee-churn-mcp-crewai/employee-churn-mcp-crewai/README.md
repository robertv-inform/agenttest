# Employee Churn Prediction with MCP and CrewAI

An end-to-end agentic AI system using Model Context Protocol (MCP) for employee churn prediction. This project demonstrates how to integrate FastAPI ML models, MCP servers, and CrewAI agents.

## Features

- **FastAPI ML Server**: Random Forest model for employee churn prediction
- **MCP Server**: Standardized tool interface using Model Context Protocol
- **CrewAI Agent**: Intelligent agent with reasoning capabilities
- **Anaconda Support**: Complete conda environment setup

## Prerequisites

- Anaconda or Miniconda installed
- Python 3.11+
- 3 GB free disk space

## Quick Start

### 1. Extract the Package

```bash
unzip employee-churn-mcp-crewai.zip
cd employee-churn-mcp-crewai
```

### 2. Run Setup (Choose your OS)

**Linux/Mac:**
```bash
chmod +x setup_conda.sh
./setup_conda.sh
```

**Windows:**
```batch
setup_conda.bat
```

### 3. Run the System

**Terminal 1 - Start ML API:**
```bash
conda activate ml-api-env
cd ml-api
python -m uvicorn mlapi:app --reload
```

**Terminal 2 - Run CrewAI Agent:**
```bash
conda activate crewai-env
cd crewai-agent
python agent.py
```

## Project Structure

```
employee-churn-mcp-crewai/
├── ml-api/              # FastAPI machine learning server
│   ├── mlapi.py
│   └── requirements.txt
├── mcp-server/          # Model Context Protocol server
│   ├── server.py
│   └── requirements.txt
├── crewai-agent/        # CrewAI intelligent agent
│   ├── agent.py
│   └── requirements.txt
├── setup_conda.sh       # Linux/Mac setup script
├── setup_conda.bat      # Windows setup script
└── README.md
```

## Testing

### Test ML API

```bash
curl -X POST http://127.0.0.1:8000/ \
  -H "Content-Type: application/json" \
  -d '{{
    "YearsAtCompany": 2,
    "EmployeeSatisfaction": 0.35,
    "Position": "Non-Manager",
    "Salary": 2.0
  }}'
```

### Test MCP Server

```bash
conda activate mcp-server-env
cd mcp-server
pip install "mcp[dev]"
python -m mcp dev server.py
```

## Configuration

### Change Employee Data

Edit `crewai-agent/agent.py` and modify the Task description:

```python
description="""Analyze the following employee:
- Years at Company: 5
- Employee Satisfaction: 0.75
- Position: Manager
- Salary: 4.0
"""
```

### Add More Agents

You can add additional agents to the crew:

```python
analyst_agent = Agent(
    role="HR Data Analyst",
    goal="Provide detailed analysis of churn patterns",
    backstory="Expert in HR analytics",
    tools=mcp_tools,
    verbose=True
)

crew = Crew(
    agents=[churn_agent, analyst_agent],
    tasks=[prediction_task, analysis_task],
    verbose=True
)
```

## Troubleshooting

### MCP Connection Issues

If the agent can't connect to MCP server:

```bash
# Verify MCP is installed
conda activate mcp-server-env
conda list | grep mcp

# Reinstall if needed
conda install -c conda-forge mcp -y
```

### Port Already in Use

If port 8000 is busy:

```bash
# Linux/Mac
lsof -i :8000
kill -9 <PID>

# Windows
netstat -ano | findstr :8000
taskkill /PID <PID> /F
```

### CrewAI Creating Virtual Environments

If CrewAI tries to create its own venv:

```bash
export CREWAI_DISABLE_VENV=1  # Linux/Mac
set CREWAI_DISABLE_VENV=1     # Windows
```

## Architecture

1. **ML API Layer**: FastAPI serves the Random Forest model
2. **MCP Server Layer**: Exposes ML API as standardized tools
3. **Agent Layer**: CrewAI agent uses MCP tools for predictions

## Learn More

- [Model Context Protocol](https://modelcontextprotocol.io/)
- [CrewAI Documentation](https://docs.crewai.com/)
- [FastAPI Documentation](https://fastapi.tiangolo.com/)

## License

MIT License - Feel free to use and modify for your projects.

## Author

Built for demonstrating MCP integration with CrewAI agents.


=============================================================

How to Use the Package

Step 1: Download
The zip file is now available in your current directory.

Step 2: Extract

bash
# Linux/Mac
unzip employee-churn-mcp-crewai.zip
cd employee-churn-mcp-crewai

# Windows
Right-click > Extract All

Step 3: Run Setup

bash
# Linux/Mac
chmod +x setup_conda.sh
./setup_conda.sh

# Windows
setup_conda.bat

Step 4: Run the System

Terminal 1:

bash
conda activate ml-api-env
cd ml-api
python -m uvicorn mlapi:app --reload

Terminal 2:

bash
conda activate crewai-env
cd crewai-agent
python agent.py

Key Features

    Zero Configuration: Works out-of-the-box with Anaconda

    Cross-Platform: Includes scripts for Windows, Linux, and Mac

    Complete Stack: FastAPI + MCP + CrewAI fully integrated

    Production Ready: Includes error handling and logging

    Documented: Comprehensive README and quickstart guide

    Small Size: Only 7.37 KB - easy to share

What Each Component Does

ML API (ml-api/): Serves a Random Forest model via FastAPI that predicts employee churn based on years at company, satisfaction, position, and salary.

==========================================================================
