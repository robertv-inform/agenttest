import os
import sys
from crewai import Agent, Task, Crew
from crewai_tools import MCPServerAdapter
from mcp import StdioServerParameters

def main():
    # Get the MCP server path
    mcp_server_path = os.path.abspath("../mcp-server/server.py")

    # Get the conda environment's python executable
    conda_python = sys.executable

    print(f"Using Python: {{conda_python}}")
    print(f"Connecting to MCP server at: {{mcp_server_path}}")

    # Configure MCP server connection with conda python
    server_params = StdioServerParameters(
        command=conda_python,
        args=[mcp_server_path],
        env=os.environ.copy()
    )

    # Use context manager for MCP tools
    try:
        with MCPServerAdapter(server_params, connect_timeout=60) as mcp_tools:
            print(f"✅ Connected to MCP server. Available tools: {{len(mcp_tools)}}")

            # Create the agent
            churn_agent = Agent(
                role="Employee Churn Prediction Specialist",
                goal="Analyze employee data and predict churn risk accurately",
                backstory="""You are an expert HR analytics specialist with deep knowledge 
                of employee retention patterns. You use advanced machine learning tools to 
                predict which employees are at risk of leaving the company.""",
                tools=mcp_tools,
                verbose=True,
                allow_delegation=False
            )

            # Create the task
            prediction_task = Task(
                description="""Analyze the following employee and predict if they will churn:

                Employee Details:
                - Years at Company: 2
                - Employee Satisfaction: 0.35
                - Position: Non-Manager
                - Salary: 2.0 (on scale of 1-5)

                Use the PredictChurn tool to make the prediction and provide insights.""",
                expected_output="""A comprehensive analysis including:
                1. Churn prediction (will churn or will stay)
                2. Churn probability percentage
                3. Key risk factors identified
                4. Recommendations for retention""",
                agent=churn_agent
            )

            # Create and run the crew
            crew = Crew(
                agents=[churn_agent],
                tasks=[prediction_task],
                verbose=True
            )

            print("\n🚀 Starting CrewAI agent with MCP tools...\n")
            result = crew.kickoff()

            print("\n" + "="*80)
            print("FINAL RESULT")
            print("="*80)
            print(result)
            print("="*80 + "\n")

    except Exception as e:
        print(f"❌ Error: {{e}}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()
