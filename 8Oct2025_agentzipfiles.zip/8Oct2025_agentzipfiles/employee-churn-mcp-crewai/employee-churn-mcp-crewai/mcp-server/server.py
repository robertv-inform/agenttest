from mcp.server.fastmcp import FastMCP
import json
import requests
from typing import List
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

mcp = FastMCP("churnandburn")

@mcp.tool()
def PredictChurn(data: List[dict]) -> str:
    """This tool predicts whether an employee will churn or not.

    Args:
        data: employee attributes. Example:
        [{{
            'YearsAtCompany': 10,
            'EmployeeSatisfaction': 0.99,
            'Position': 'Non-Manager',
            'Salary': 5.0
        }}]

    Returns:
        str: prediction result with churn probability
    """
    try:
        payload = data[0]
        logger.info(f"Making prediction request with payload: {{payload}}")

        response = requests.post(
            "http://127.0.0.1:8000",
            headers={{
                "Accept": "application/json",
                "Content-Type": "application/json"
            }},
            data=json.dumps(payload),
            timeout=10
        )

        response.raise_for_status()
        result = response.json()
        logger.info(f"Prediction result: {{result}}")

        return json.dumps(result)

    except requests.exceptions.RequestException as e:
        logger.error(f"Error making prediction request: {{e}}")
        return json.dumps({{"error": str(e), "message": "Failed to connect to ML API"}})
    except Exception as e:
        logger.error(f"Unexpected error: {{e}}")
        return json.dumps({{"error": str(e)}})

if __name__ == "__main__":
    mcp.run(transport="stdio")
