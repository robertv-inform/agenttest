from fastapi import FastAPI
from pydantic import BaseModel
import pickle
import numpy as np
from sklearn.ensemble import RandomForestClassifier
import joblib

app = FastAPI()

# Train a simple model (in production, load pre-trained model)
def train_model():
    # Sample training data
    X_train = np.array([
        [10, 0.99, 0, 5],  # YearsAtCompany, Satisfaction, Position(0=Non-Manager), Salary
        [2, 0.45, 0, 2],
        [5, 0.78, 1, 4],
        [1, 0.23, 0, 1],
        [15, 0.91, 1, 5],
        [3, 0.34, 0, 2],
        [8, 0.88, 1, 4],
        [1, 0.15, 0, 1],
    ])
    y_train = np.array([0, 1, 0, 1, 0, 1, 0, 1])  # 0=No Churn, 1=Churn

    model = RandomForestClassifier(n_estimators=100, random_state=42)
    model.fit(X_train, y_train)
    joblib.dump(model, 'model.pkl')
    return model

# Load or train model
try:
    model = joblib.load('model.pkl')
except:
    model = train_model()

class EmployeeData(BaseModel):
    YearsAtCompany: int
    EmployeeSatisfaction: float
    Position: str
    Salary: float

@app.post("/")
async def predict_churn(data: EmployeeData):
    # Convert Position to numeric
    position_numeric = 1 if data.Position == "Manager" else 0

    # Prepare features
    features = np.array([[
        data.YearsAtCompany,
        data.EmployeeSatisfaction,
        position_numeric,
        data.Salary
    ]])

    # Make prediction
    prediction = model.predict(features)[0]
    probability = model.predict_proba(features)[0]

    return {
        "prediction": int(prediction),
        "churn_probability": float(probability[1]),
        "message": "Employee likely to churn" if prediction == 1 else "Employee likely to stay"
    }

@app.get("/health")
async def health_check():
    return {"status": "healthy"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
