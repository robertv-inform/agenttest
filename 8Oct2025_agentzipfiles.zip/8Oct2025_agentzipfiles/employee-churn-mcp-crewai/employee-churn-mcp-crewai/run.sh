#!/bin/bash

echo "Starting FastAPI ML Server..."
cd ml-api
conda run -n ml-api-env python -m uvicorn mlapi:app --host 0.0.0.0 --port 8000 &
API_PID=$!

echo "Waiting for API to start..."
sleep 5

echo "Starting CrewAI Agent..."
cd ../crewai-agent
conda run -n crewai-env python agent.py

echo "Cleaning up..."
kill $API_PID
