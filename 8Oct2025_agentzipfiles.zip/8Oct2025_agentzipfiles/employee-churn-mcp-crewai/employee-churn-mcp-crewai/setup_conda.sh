#!/bin/bash

PROJECT_DIR="."

echo "======================================"
echo "Employee Churn MCP CrewAI Setup"
echo "======================================"
echo ""

echo "Setting up ML API Environment..."
conda create -n ml-api-env python=3.11 -y
eval "$(conda shell.bash hook)"
conda activate ml-api-env
cd ml-api
pip install -r requirements.txt
cd ..
echo "✅ ML API environment ready"
echo ""

echo "Setting up MCP Server Environment..."
conda create -n mcp-server-env python=3.11 -y
conda activate mcp-server-env
cd mcp-server
conda install -c conda-forge mcp -y
pip install -r requirements.txt
cd ..
echo "✅ MCP Server environment ready"
echo ""

echo "Setting up CrewAI Agent Environment..."
conda create -n crewai-env python=3.11 -y
conda activate crewai-env
cd crewai-agent
pip install -r requirements.txt
conda install -c conda-forge mcp -y
cd ..
echo "✅ CrewAI Agent environment ready"
echo ""

echo "======================================"
echo "✅ Setup Complete!"
echo "======================================"
echo ""
echo "To run the system:"
echo "1. Terminal 1: conda activate ml-api-env && cd ml-api && python -m uvicorn mlapi:app --reload"
echo "2. Terminal 2: conda activate crewai-env && cd crewai-agent && python agent.py"
