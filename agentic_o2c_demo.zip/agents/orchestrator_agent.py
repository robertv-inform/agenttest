from crewai import Agent
from config import MODEL_NAME

def create_orchestrator(o2c_agent, weather_agent):
    return Agent(
        name="Orchestrator",
        role="Route tasks between SAP and Weather agents",
        goal="Determine which agent should handle user query",
        llm=MODEL_NAME,
        delegation=True,
    )
