SAP_BASE_URL = "YOUR_SAP_SANDBOX_URL"
SAP_API_KEY = "YOUR_API_KEY"
OPEN_METEO_URL = "https://api.open-meteo.com/v1/forecast"
MODEL_NAME = "gpt-4o-mini"
