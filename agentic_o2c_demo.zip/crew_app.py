from crewai import Crew, Task
from agents.o2c_agent import create_o2c_agent
from agents.weather_agent import create_weather_agent
from agents.orchestrator_agent import create_orchestrator
from mcp_client import connect_to_mcp_tools

sap_tool, weather_tool = connect_to_mcp_tools()

o2c = create_o2c_agent(sap_tool)
weather = create_weather_agent(weather_tool)
orchestrator = create_orchestrator(o2c, weather)

task = Task(
    description="Route user queries to SAP or Weather agent",
    agent=orchestrator,
)

crew = Crew(agents=[orchestrator, o2c, weather], tasks=[task])

if __name__ == "__main__":
    print("System ready!")
    while True:
        query = input("You: ")
        print("AI:", crew.run(query))
