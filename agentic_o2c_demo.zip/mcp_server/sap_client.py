import requests
from config import SAP_BASE_URL, SAP_API_KEY

def get_sales_orders(top: int):
    url = f"{SAP_BASE_URL}/A_SalesOrder?$top={top}&$format=json"
    headers = {"APIKey": SAP_API_KEY, "Accept": "application/json"}
    resp = requests.get(url, headers=headers)
    resp.raise_for_status()
    return resp.json()
