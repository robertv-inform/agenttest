from fastmcp import MCP
from sap_client import get_sales_orders
from weather_client import get_weather_forecast

mcp = MCP()

@mcp.tool()
def sap_sales_orders(top: int = 5):
    return get_sales_orders(top)

@mcp.tool()
def weather_forecast(city: str):
    return get_weather_forecast(city)

if __name__ == "__main__":
    mcp.run()
