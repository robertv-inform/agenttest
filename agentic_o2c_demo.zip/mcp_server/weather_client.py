import requests
from geopy.geocoders import Nominatim
from config import OPEN_METEO_URL

def city_to_coords(city):
    loc = Nominatim(user_agent="weather-agent").geocode(city)
    return loc.latitude, loc.longitude

def get_weather_forecast(city):
    lat, lon = city_to_coords(city)
    url = f"{OPEN_METEO_URL}?latitude={lat}&longitude={lon}&hourly=temperature_2m"
    resp = requests.get(url)
    resp.raise_for_status()
    return resp.json()
