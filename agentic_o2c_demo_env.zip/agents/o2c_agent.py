from crewai import Agent, Tool
from config import MODEL_NAME

def create_o2c_agent(sap_tool: Tool):
    return Agent(
        name="O2CAgent",
        role="Fetches SAP data",
        goal="Retrieve SAP sales orders",
        tools=[sap_tool],
        llm=MODEL_NAME,
    )
