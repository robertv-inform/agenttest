from crewai import Agent, Tool
from config import MODEL_NAME

def create_weather_agent(weather_tool: Tool):
    return Agent(
        name="WeatherAgent",
        role="Fetch weather",
        goal="Provide forecasts",
        tools=[weather_tool],
        llm=MODEL_NAME,
    )
