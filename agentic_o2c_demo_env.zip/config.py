from dotenv import load_dotenv
import os

load_dotenv()

SAP_BASE_URL = os.getenv("SAP_BASE_URL")
SAP_API_KEY = os.getenv("SAP_API_KEY")
OPEN_METEO_URL = os.getenv("OPEN_METEO_URL", "https://api.open-meteo.com/v1/forecast")

MODEL_NAME = "gpt-4o-mini"
