from mcp import Client

def connect_to_mcp_tools():
    client = Client("http://localhost:8000")
    return client.get_tool("sap_sales_orders"), client.get_tool("weather_forecast")
