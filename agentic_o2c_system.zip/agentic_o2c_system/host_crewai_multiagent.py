
import os
from dotenv import load_dotenv

from crewai import Agent, Task, Crew, Process, LLM
from crewai_tools import MCPServerAdapter
from mcp import StdioServerParameters

load_dotenv()

llm = LLM(
    model="openai/gpt-4o",
    temperature=0.1,
)

server_params = StdioServerParameters(
    command="python",
    args=["sap_sales_mcp_server.py"],
    env={**os.environ},
)

mcp_adapter = MCPServerAdapter(server_params)
mcp_tools = mcp_adapter.tools

planner_agent = Agent(
    role="SAP O2C Orchestrator",
    goal="Plan and route user SAP O2C requests.",
    backstory="Expert SAP SD architect.",
    llm=llm,
    allow_delegation=True,
)

reader_agent = Agent(
    role="Sales Order Inquiry Agent",
    goal="Fetch and summarize SAP sales orders.",
    backstory="SAP SD inquiry specialist.",
    llm=llm,
    tools=mcp_tools,
)

writer_agent = Agent(
    role="Sales Order Creation Agent",
    goal="Create demo orders using MCP tools.",
    backstory="SAP SD creation specialist.",
    llm=llm,
    tools=mcp_tools,
)

planner_task = Task(
    description="Interpret user request {user_query} and delegate.",
    agent=planner_agent,
)
reader_task = Task(
    description="Read SAP orders using MCP.",
    agent=reader_agent,
)
writer_task = Task(
    description="Create SAP demo order using MCP.",
    agent=writer_agent,
)

crew = Crew(
    agents=[planner_agent, reader_agent, writer_agent],
    tasks=[planner_task, reader_task, writer_task],
    process=Process.sequential,
    verbose=True,
)

def run_o2c_flow(user_query: str):
    try:
        return crew.kickoff(inputs={"user_query": user_query})
    finally:
        mcp_adapter.stop()

if __name__ == "__main__":
    print("SAP O2C MCP + CrewAI System")
    q = input("Enter SAP request: ")
    print(run_o2c_flow(q))
