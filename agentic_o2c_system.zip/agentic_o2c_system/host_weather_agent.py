
import os
from dotenv import load_dotenv

from crewai import Agent, Task, Crew, LLM
from crewai_tools import MCPServerAdapter
from mcp import StdioServerParameters

load_dotenv()

llm = LLM(
    model="openai/gpt-4o",
    temperature=0.2,
)

server_params = StdioServerParameters(
    command="python",
    args=["weather_mcp_server.py"],
    env={**os.environ},
)

mcp_adapter = MCPServerAdapter(server_params)
mcp_tools = mcp_adapter.tools

weather_agent = Agent(
    role="Weather Assistant",
    goal="Provide weather forecasts via MCP.",
    backstory="Expert meteorologist using Open-Meteo.",
    llm=llm,
    tools=mcp_tools,
)

weather_task = Task(
    description="Use MCP tool get_forecast(city, days) to fetch forecast for {query}.",
    agent=weather_agent,
)

crew = Crew(
    agents=[weather_agent],
    tasks=[weather_task],
    verbose=True,
)

def run_weather(query: str):
    try:
        return crew.kickoff(inputs={"query": query})
    finally:
        mcp_adapter.stop()

if __name__ == "__main__":
    print("Weather Agent + MCP Server")
    while True:
        q = input("Weather Query: ")
        if q.lower() == "exit":
            break
        print(run_weather(q))
