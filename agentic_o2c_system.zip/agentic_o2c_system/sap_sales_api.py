
import os
import requests
from dotenv import load_dotenv

load_dotenv()

SAP_API_KEY = os.getenv("SAP_API_KEY")
SAP_BASE_URL = os.getenv("SAP_BASE_URL")

session = requests.Session()

def base_headers(extra=None):
    h = {
        "APIKey": SAP_API_KEY,
        "Accept": "application/json",
        "Content-Type": "application/json",
    }
    if extra:
        h.update(extra)
    return h

def list_sales_orders(top=5):
    url = f"{SAP_BASE_URL}/A_SalesOrder"
    params = {"$top": str(top)}
    r = session.get(url, params=params, headers=base_headers(), timeout=20)
    r.raise_for_status()
    return r.json()

def get_sales_order(order_id: str):
    url = f"{SAP_BASE_URL}/A_SalesOrder('{order_id}')"
    r = session.get(url, headers=base_headers(), timeout=20)
    r.raise_for_status()
    return r.json()

def fetch_csrf():
    url = f"{SAP_BASE_URL}/A_SalesOrder"
    r = session.get(url, headers=base_headers({"X-CSRF-Token": "Fetch"}), timeout=20)
    r.raise_for_status()
    return {
        "token": r.headers.get("X-CSRF-Token"),
        "cookies": r.cookies
    }

def create_sales_order(payload):
    csrf = fetch_csrf()
    url = f"{SAP_BASE_URL}/A_SalesOrder"
    r = session.post(
        url,
        json=payload,
        headers=base_headers({"X-CSRF-Token": csrf["token"]}),
        cookies=csrf["cookies"],
        timeout=20,
    )
    r.raise_for_status()
    return r.json()
