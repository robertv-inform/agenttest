
from typing import Any, Dict, List
from mcp.server.fastmcp import FastMCP
from sap_sales_api import (
    list_sales_orders as sap_list_sales_orders,
    get_sales_order as sap_get_sales_order,
    create_sales_order as sap_create_sales_order,
)

mcp = FastMCP("sap-sales-order-mcp")

@mcp.tool()
def list_sales_orders(top: int = 5):
    raw = sap_list_sales_orders(top=top)
    return raw.get("d", {}).get("results", [])

@mcp.tool()
def get_sales_order(order_id: str):
    raw = sap_get_sales_order(order_id)
    return raw.get("d", {})

@mcp.tool()
def create_demo_sales_order(
    sold_to_party: str,
    material: str = "TG11",
    quantity: float = 1.0
):
    payload = {
        "SalesOrderType": "OR",
        "SalesOrganization": "1010",
        "DistributionChannel": "10",
        "OrganizationDivision": "00",
        "SoldToParty": sold_to_party,
        "TransactionCurrency": "EUR",
        "PurchaseOrderByCustomer": "CrewAI MCP Demo",
        "to_Item": {
            "results": [
                {
                    "SalesOrderItem": "10",
                    "Material": material,
                    "RequestedQuantity": str(quantity),
                    "RequestedQuantityUnit": "EA"
                }
            ]
        }
    }
    raw = sap_create_sales_order(payload)
    return raw.get("d", {})

if __name__ == "__main__":
    mcp.run(transport="stdio")
