
from mcp.server.fastmcp import FastMCP
import httpx

mcp = FastMCP("weather-mcp")

CITY_COORDS = {
    "chennai": (13.0827, 80.2707),
    "bengaluru": (12.9716, 77.5946),
    "bangalore": (12.9716, 77.5946),
    "mumbai": (19.0760, 72.8777),
    "delhi": (28.7041, 77.1025),
}

@mcp.tool()
def get_forecast(city: str, days: int = 1):
    city_l = city.lower().strip()

    if city_l not in CITY_COORDS:
        return {"error": f"Unknown city: {city}"}

    lat, lon = CITY_COORDS[city_l]

    url = (
        f"https://api.open-meteo.com/v1/forecast?"
        f"latitude={lat}&longitude={lon}&daily=temperature_2m_max,"
        f"temperature_2m_min&timezone=auto"
    )

    with httpx.Client() as client:
        r = client.get(url, timeout=10)
        r.raise_for_status()
        data = r.json()

    days_data = []
    for d, tmax, tmin in zip(
        data["daily"]["time"],
        data["daily"]["temperature_2m_max"],
        data["daily"]["temperature_2m_min"]
    ):
        days_data.append({
            "date": d,
            "temp_max": tmax,
            "temp_min": tmin
        })

    return {"city": city, "forecast": days_data[:days]}

if __name__ == "__main__":
    mcp.run(transport="stdio")
