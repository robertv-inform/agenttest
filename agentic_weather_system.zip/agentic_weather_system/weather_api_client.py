
# weather_api_client.py
import httpx

GEOCODE_URL = "https://geocoding-api.open-meteo.com/v1/search"
FORECAST_URL = "https://api.open-meteo.com/v1/forecast"


async def geocode_city(city: str):
    async with httpx.AsyncClient(timeout=15) as client:
        r = await client.get(
            GEOCODE_URL,
            params={"name": city, "count": 1, "language": "en"},
        )
        r.raise_for_status()
        data = r.json()

    results = data.get("results") or []
    if not results:
        raise ValueError(f"City not found: {city}")

    loc = results[0]
    return {
        "name": loc.get("name", city),
        "country": loc.get("country"),
        "latitude": loc["latitude"],
        "longitude": loc["longitude"],
    }


async def get_forecast(city: str, days: int = 3):
    loc = await geocode_city(city)

    if days < 1:
        days = 1
    if days > 7:
        days = 7

    async with httpx.AsyncClient(timeout=15) as client:
        r = await client.get(
            FORECAST_URL,
            params={
                "latitude": loc["latitude"],
                "longitude": loc["longitude"],
                "daily": "temperature_2m_max,temperature_2m_min,precipitation_probability_max",
                "timezone": "auto",
                "forecast_days": days,
            },
        )
        r.raise_for_status()
        data = r.json()

    daily = data.get("daily", {})
    times = daily.get("time", [])
    tmax = daily.get("temperature_2m_max", [])
    tmin = daily.get("temperature_2m_min", [])
    prec = daily.get("precipitation_probability_max", [])

    forecast = []
    for i in range(len(times)):
        forecast.append(
            {
                "date": times[i],
                "temp_max_c": tmax[i],
                "temp_min_c": tmin[i],
                "precipitation_probability_max": prec[i],
            }
        )

    return {
        "city": loc["name"],
        "country": loc["country"],
        "latitude": loc["latitude"],
        "longitude": loc["longitude"],
        "forecast": forecast,
    }
