
# weather_mcp_server.py
from mcp.server.fastmcp import FastMCP
from weather_api_client import get_forecast as _get_forecast
from weather_api_client import geocode_city as _geocode_city

mcp = FastMCP("weather-mcp")


@mcp.tool()
async def get_current_weather(city: str):
    loc = await _geocode_city(city)
    # current weather via forecast endpoint by taking day 0 min/max
    fc = await _get_forecast(city, days=1)
    today = fc["forecast"][0]

    return {
        "city": loc["name"],
        "latitude": loc["latitude"],
        "longitude": loc["longitude"],
        "temp_min_c": today["temp_min_c"],
        "temp_max_c": today["temp_max_c"],
        "precipitation_probability": today["precipitation_probability_max"],
    }


@mcp.tool()
async def get_forecast(city: str, days: int = 3):
    return await _get_forecast(city, days)


if __name__ == "__main__":
    mcp.run_stdio_server()
