# Multi-Agent MCP System Architecture

## Architecture Diagram

```
┌─────────────────────────────────────────────────────────────────────┐
│                           USER REQUEST                               │
└─────────────────────────┬───────────────────────────────────────────┘
                          │
                          ▼
┌─────────────────────────────────────────────────────────────────────┐
│                      HOST APPLICATION                                │
│  ┌───────────────────────────────────────────────────────────────┐  │
│  │              FastAPI Server (main.py)                         │  │
│  │  - Receives user queries                                      │  │
│  │  - Coordinates agent orchestration                            │  │
│  │  - Returns final responses                                    │  │
│  └───────────────────────────────┬───────────────────────────────┘  │
└────────────────────────────────────┼──────────────────────────────────┘
                                     │
                                     ▼
┌─────────────────────────────────────────────────────────────────────┐
│                    ORCHESTRATOR (orchestrator.py)                    │
│  ┌───────────────────────────────────────────────────────────────┐  │
│  │  - Analyzes user intent using LLM                             │  │
│  │  - Determines which agent(s) to invoke                        │  │
│  │  - Coordinates multi-agent workflows                          │  │
│  │  - Aggregates results from multiple agents                    │  │
│  └───────────────────────┬───────────────────────────────────────┘  │
└──────────────────────────┼──────────────────────────────────────────┘
                           │
          ┌────────────────┴────────────────┐
          │                                 │
          ▼                                 ▼
┌─────────────────────┐          ┌─────────────────────┐
│   SAP AGENT         │          │  WEATHER AGENT      │
│  (agents/sap.py)    │          │ (agents/weather.py) │
│                     │          │                     │
│ - Sales Order Ops   │          │ - Weather Forecast  │
│ - LLM Analysis      │          │ - Location Based    │
│ - Result Formatting │          │ - LLM Formatting    │
└──────┬──────────────┘          └──────┬──────────────┘
       │                                │
       ▼                                ▼
┌─────────────────────┐          ┌─────────────────────┐
│  MCP CLIENT         │          │  MCP CLIENT         │
│ (mcp/client.py)     │          │ (mcp/client.py)     │
│                     │          │                     │
│ - Tool Discovery    │          │ - Tool Discovery    │
│ - Request Handling  │          │ - Request Handling  │
│ - Response Parse    │          │ - Response Parse    │
└──────┬──────────────┘          └──────┬──────────────┘
       │                                │
       ▼                                ▼
┌─────────────────────┐          ┌─────────────────────┐
│  MCP SERVER         │          │  MCP SERVER         │
│ (mcp/sap_server.py) │          │(mcp/weather_srv.py) │
│                     │          │                     │
│ Tools:              │          │ Tools:              │
│ - get_sales_orders  │          │ - get_weather       │
│ - create_order      │          │ - get_forecast      │
│ - get_order_detail  │          │ - search_location   │
└──────┬──────────────┘          └──────┬──────────────┘
       │                                │
       ▼                                ▼
┌─────────────────────┐          ┌─────────────────────┐
│  SAP API            │          │  WEATHER API        │
│ (SAP O2C API)       │          │ (OpenWeather API)   │
│                     │          │                     │
│ - Business Hub API  │          │ - Free Tier         │
│ - Auth via API Key  │          │ - REST API          │
└─────────────────────┘          └─────────────────────┘
```

## End-to-End Flow

### Flow 1: SAP Sales Order Query

```
1. User Request: "Show me recent sales orders"
   ↓
2. Host (FastAPI) receives request
   ↓
3. Orchestrator analyzes intent with OpenAI LLM
   → Determines: Need SAP Agent
   ↓
4. SAP Agent initialized
   ↓
5. MCP Client (SAP) calls list_tools()
   → Discovers: get_sales_orders, create_order, get_order_detail
   ↓
6. LLM suggests: Use "get_sales_orders" tool
   ↓
7. MCP Client sends request to SAP MCP Server
   ↓
8. SAP MCP Server:
   - Loads SAP_API_KEY from .env
   - Calls SAP Business Hub O2C API
   - Returns sales order data
   ↓
9. SAP Agent receives raw data
   ↓
10. LLM formats result into human-readable response
    ↓
11. Response returned to user via Host
```

### Flow 2: Weather Forecast Query

```
1. User Request: "What's the weather in San Francisco?"
   ↓
2. Host receives request
   ↓
3. Orchestrator analyzes with LLM
   → Determines: Need Weather Agent
   ↓
4. Weather Agent initialized
   ↓
5. MCP Client (Weather) discovers tools
   → get_weather, get_forecast, search_location
   ↓
6. LLM suggests: Use "get_forecast" for "San Francisco"
   ↓
7. MCP Server calls OpenWeather API
   - Uses WEATHER_API_KEY from .env
   ↓
8. Weather Agent formats result with LLM
   ↓
9. Response returned to user
```

### Flow 3: Multi-Agent Query

```
1. User: "Show sales orders and weather for delivery locations"
   ↓
2. Orchestrator LLM analyzes → Multi-agent needed
   ↓
3. Parallel Execution:
   ┌─────────────────┐         ┌─────────────────┐
   │  SAP Agent      │         │ Weather Agent   │
   │  - Get Orders   │         │ - Get Weather   │
   │  - Extract Locs │         │ - For Each Loc  │
   └────────┬────────┘         └────────┬────────┘
            │                           │
            └───────────┬───────────────┘
                        ▼
4. Orchestrator aggregates results
   ↓
5. LLM creates comprehensive report
   ↓
6. Final response to user
```

## Component Details

### 1. **Host Application** (main.py)
- FastAPI web server
- REST API endpoints
- Request/response handling
- Error management

### 2. **Orchestrator** (orchestrator.py)
- Intent detection using OpenAI
- Agent selection logic
- Multi-agent coordination
- Result aggregation

### 3. **Agents**
- **SAP Agent**: Handles SAP Business Hub operations
- **Weather Agent**: Handles weather queries
- Each uses LLM for intelligent responses

### 4. **MCP Layer**
- **MCP Client**: Standard client for all MCP servers
- **MCP Servers**: 
  - SAP Server: SAP API wrapper
  - Weather Server: OpenWeather API wrapper
- Tool discovery and execution

### 5. **LLM Integration**
- OpenAI GPT models
- Used for:
  - Intent analysis
  - Tool selection
  - Response formatting
  - Result summarization

## Configuration (.env)

```env
# OpenAI
OPENAI_API_KEY=sk-...

# SAP Business Hub
SAP_API_KEY=your_sap_o2c_api_key
SAP_BASE_URL=https://sandbox.api.sap.com/s4hanacloud

# Weather API
WEATHER_API_KEY=your_openweather_api_key
WEATHER_BASE_URL=https://api.openweathermap.org/data/2.5
```

## Technology Stack

- **Framework**: FastAPI, Pydantic
- **LLM**: OpenAI GPT-4
- **Agent Framework**: Custom (lightweight, production-ready)
- **MCP Protocol**: Custom implementation
- **APIs**: SAP Business Hub, OpenWeather
- **Config**: python-dotenv

## Production Features

✓ Environment-based configuration
✓ Error handling and logging
✓ Type safety with Pydantic
✓ Async/await for performance
✓ Modular architecture
✓ Extensible agent system
✓ Standard MCP protocol
