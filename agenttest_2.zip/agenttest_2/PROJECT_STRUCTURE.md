# Project Structure

```
sap-mcp-system/
│
├── 📄 main.py                    # FastAPI Host Application (Entry Point)
├── 📄 config.py                  # Configuration Management (.env loader)
├── 📄 orchestrator.py            # Multi-Agent Orchestrator (LLM-based routing)
├── 📄 requirements.txt           # Python Dependencies
├── 📄 .env.example              # Environment Variables Template
├── 📄 .gitignore                # Git Ignore Rules
│
├── 📁 agents/                    # Agent Implementations
│   ├── __init__.py
│   ├── sap_agent.py             # SAP Business Hub Agent
│   └── weather_agent.py         # Weather Forecast Agent
│
├── 📁 mcp/                       # Model Context Protocol Layer
│   ├── __init__.py
│   ├── client.py                # MCP Client (Universal)
│   ├── sap_server.py            # SAP MCP Server
│   └── weather_server.py        # Weather MCP Server
│
├── 📁 docs/                      # Documentation
│   ├── README.md                # Complete Documentation
│   ├── QUICKSTART.md            # Quick Start Guide
│   └── ARCHITECTURE.md          # System Architecture
│
├── 📁 deployment/                # Deployment Files
│   ├── Dockerfile               # Docker Container Definition
│   ├── docker-compose.yml       # Docker Compose Configuration
│   └── setup.sh                 # Automated Setup Script
│
└── 📁 tests/                     # Testing
    └── test_system.py           # System Integration Tests

```

## File Descriptions

### Core Application Files

**main.py** (338 lines)
- FastAPI web server implementation
- RESTful API endpoints
- Request/response handling
- System initialization
- Health checks and monitoring

**config.py** (88 lines)
- Centralized configuration management
- Environment variable loading
- Credential validation
- Type-safe configuration with Pydantic

**orchestrator.py** (285 lines)
- Multi-agent coordination
- LLM-based intent analysis
- Agent selection and routing
- Result synthesis and aggregation

### Agent Layer

**agents/sap_agent.py** (172 lines)
- SAP Business Hub integration
- Sales order operations
- LLM-powered tool selection
- Response formatting

**agents/weather_agent.py** (166 lines)
- OpenWeather API integration
- Weather and forecast queries
- Location-based services
- Intelligent response generation

### MCP Protocol Layer

**mcp/client.py** (95 lines)
- Universal MCP client
- Tool discovery protocol
- Tool execution handling
- Error management

**mcp/sap_server.py** (198 lines)
- SAP API wrapper
- MCP tool definitions
- Sales order CRUD operations
- API authentication

**mcp/weather_server.py** (199 lines)
- OpenWeather API wrapper
- Weather data tools
- Forecast operations
- Location search

## Lines of Code Summary

| Component | Files | Lines | Description |
|-----------|-------|-------|-------------|
| Host | 1 | 338 | FastAPI application |
| Config | 1 | 88 | Configuration management |
| Orchestrator | 1 | 285 | Multi-agent coordinator |
| Agents | 2 | 338 | SAP + Weather agents |
| MCP Layer | 3 | 492 | Protocol implementation |
| Tests | 1 | 97 | Integration tests |
| **Total** | **9** | **~1,638** | **Production code** |

## Key Features by File

### main.py
✓ FastAPI server setup
✓ CORS configuration
✓ Multiple endpoints (/query, /sap/query, /weather/query)
✓ Health checks
✓ MCP tool discovery endpoint
✓ Error handling
✓ Logging

### orchestrator.py
✓ LLM-based intent detection
✓ Multi-agent workflow
✓ Parallel agent execution
✓ Result synthesis
✓ Context management

### Agents
✓ LLM tool selection
✓ MCP client integration
✓ Response formatting
✓ Error handling
✓ Capability descriptions

### MCP Servers
✓ Tool registration
✓ API integration
✓ Parameter validation
✓ Response formatting
✓ Error handling

## Dependencies

```
fastapi==0.104.1          # Web framework
uvicorn==0.24.0           # ASGI server
python-dotenv==1.0.0      # Environment management
pydantic==2.5.0           # Data validation
openai==1.3.5             # LLM integration
httpx==0.25.1             # HTTP client
aiohttp==3.9.1            # Async HTTP
```

## Environment Variables Required

```env
# LLM
OPENAI_API_KEY

# SAP Business Hub
SAP_API_KEY
SAP_BASE_URL

# Weather API
WEATHER_API_KEY
WEATHER_BASE_URL

# Application
HOST (default: 0.0.0.0)
PORT (default: 8000)
LOG_LEVEL (default: INFO)
```

## Architecture Highlights

1. **Modular Design**: Each component is independent and testable
2. **MCP Protocol**: Standard protocol for tool integration
3. **LLM Intelligence**: AI-powered at every layer
4. **Production Ready**: Error handling, logging, type safety
5. **Async/Await**: High-performance async operations
6. **Extensible**: Easy to add new agents and tools

## API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/` | GET | System information |
| `/health` | GET | Health check |
| `/agents` | GET | List agents |
| `/mcp/tools` | GET | List all MCP tools |
| `/query` | POST | Multi-agent query |
| `/sap/query` | POST | SAP-specific query |
| `/weather/query` | POST | Weather-specific query |

## Workflow Example

```
User: "Show sales orders and weather"
  ↓
main.py receives request
  ↓
orchestrator.py analyzes intent
  ↓ (parallel execution)
  ├─→ sap_agent.py
  │     ↓
  │   mcp/client.py
  │     ↓
  │   mcp/sap_server.py
  │     ↓
  │   SAP API
  │
  └─→ weather_agent.py
        ↓
      mcp/client.py
        ↓
      mcp/weather_server.py
        ↓
      OpenWeather API
  ↓
orchestrator.py synthesizes results
  ↓
main.py returns response to user
```

## Production Deployment Checklist

- [ ] Configure all API keys
- [ ] Set up HTTPS/SSL
- [ ] Implement authentication
- [ ] Add rate limiting
- [ ] Configure logging aggregation
- [ ] Set up monitoring
- [ ] Use process manager
- [ ] Configure backups
- [ ] Set up CI/CD
- [ ] Load testing
