# Quick Start Guide

Get the Multi-Agent MCP System running in 5 minutes!

## Prerequisites

- Python 3.9 or higher
- pip package manager
- API Keys (get these first):
  - OpenAI API Key: https://platform.openai.com/api-keys
  - SAP API Key: https://api.sap.com (free sandbox)
  - OpenWeather API Key: https://openweathermap.org/api (free tier)

## Installation (Automatic)

### Option 1: Using Setup Script (Recommended)

```bash
cd sap-mcp-system
chmod +x setup.sh
./setup.sh
```

Then edit `.env` file with your API keys.

### Option 2: Manual Setup

```bash
cd sap-mcp-system

# Create virtual environment
python3 -m venv venv

# Activate virtual environment
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt

# Create .env file
cp .env.example .env
# Edit .env and add your API keys
```

## Configuration

Edit `.env` file:

```env
OPENAI_API_KEY=sk-your-key-here
SAP_API_KEY=your-sap-key-here
WEATHER_API_KEY=your-weather-key-here
```

## Run the System

```bash
python main.py
```

Expected output:
```
INFO:     Started server process
INFO:     Waiting for application startup.
INFO:     Application startup complete.
INFO:     Uvicorn running on http://0.0.0.0:8000
```

## Test the System

### 1. Check Health

```bash
curl http://localhost:8000/health
```

### 2. View Available Tools

```bash
curl http://localhost:8000/mcp/tools
```

### 3. Test SAP Agent

```bash
curl -X POST http://localhost:8000/sap/query \
  -H "Content-Type: application/json" \
  -d '{"query": "Show me recent sales orders"}'
```

### 4. Test Weather Agent

```bash
curl -X POST http://localhost:8000/weather/query \
  -H "Content-Type: application/json" \
  -d '{"query": "What is the weather in New York?"}'
```

### 5. Test Multi-Agent

```bash
curl -X POST http://localhost:8000/query \
  -H "Content-Type: application/json" \
  -d '{"query": "Get sales data and weather forecast"}'
```

## Access API Documentation

Open in your browser:
- **Swagger UI**: http://localhost:8000/docs
- **ReDoc**: http://localhost:8000/redoc

## Example Queries

### SAP Queries
- "Show me recent sales orders"
- "Get sales order details for order 123"
- "List all orders from last week"

### Weather Queries
- "What's the weather in San Francisco?"
- "Give me a 5-day forecast for London"
- "Current weather in Paris"

### Multi-Agent Queries
- "Get sales orders and check weather for delivery locations"
- "Show me sales data and weather conditions"

## Using Python Client

```python
import httpx
import json

async def query_system():
    async with httpx.AsyncClient() as client:
        response = await client.post(
            "http://localhost:8000/query",
            json={"query": "Show me sales orders and weather"}
        )
        result = response.json()
        print(json.dumps(result, indent=2))

# Run the query
import asyncio
asyncio.run(query_system())
```

## Docker Deployment

```bash
# Build and run with Docker Compose
docker-compose up -d

# View logs
docker-compose logs -f

# Stop
docker-compose down
```

## Troubleshooting

### Port 8000 already in use
```bash
# Change port in .env file
PORT=8001
```

### API Key errors
- Verify all API keys in `.env` are correct
- Check API key permissions and quotas
- Ensure no extra spaces in .env file

### Import errors
```bash
# Reinstall dependencies
pip install -r requirements.txt --force-reinstall
```

### Connection errors
- Check internet connectivity
- Verify API endpoints are accessible
- Review firewall settings

## Next Steps

1. **Explore API**: Visit http://localhost:8000/docs
2. **Read Documentation**: See README.md for detailed info
3. **View Architecture**: Check ARCHITECTURE.md
4. **Customize**: Add your own agents and tools

## Support

For issues:
1. Check logs in `logs/` directory
2. Verify `.env` configuration
3. Test individual components
4. Review error messages

## Production Deployment

For production:
1. Use environment variables (not .env file)
2. Set up HTTPS/SSL
3. Add authentication
4. Implement rate limiting
5. Use process manager (PM2, systemd)
6. Set up monitoring and logging
7. Use Docker/Kubernetes for scaling

---

**Ready to go!** 🚀

The system is now running and ready to handle queries. Start with the interactive API docs at http://localhost:8000/docs
