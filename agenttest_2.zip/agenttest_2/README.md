# Multi-Agent MCP System with SAP and Weather APIs

A production-ready multi-agent system built with Model Context Protocol (MCP) for integrating SAP Business Hub and OpenWeather APIs with intelligent LLM-based orchestration.

## 🏗️ Architecture

```
User Request → FastAPI Host → Orchestrator (LLM) → Agents (SAP/Weather)
                                                    ↓
                                                MCP Client
                                                    ↓
                                                MCP Server
                                                    ↓
                                            External APIs
```

## ✨ Features

- **Multi-Agent System**: Coordinated SAP and Weather agents
- **MCP Protocol**: Standard Model Context Protocol implementation
- **LLM Intelligence**: OpenAI GPT-4 for intent analysis and response formatting
- **Production Ready**: Error handling, logging, type safety
- **Async/Await**: High-performance async operations
- **RESTful API**: FastAPI with automatic documentation
- **Environment Config**: Secure credential management with .env

## 📋 Prerequisites

- Python 3.9+
- OpenAI API Key
- SAP Business Hub API Key (O2C API)
- OpenWeather API Key (free tier)

## 🚀 Quick Start

### 1. Installation

```bash
cd sap-mcp-system
pip install -r requirements.txt
```

### 2. Configuration

Create a `.env` file:

```bash
cp .env.example .env
```

Edit `.env` and add your credentials:

```env
# OpenAI Configuration
OPENAI_API_KEY=sk-your-openai-api-key

# SAP Business Hub Configuration
SAP_API_KEY=your-sap-o2c-api-key
SAP_BASE_URL=https://sandbox.api.sap.com/s4hanacloud/sap/opu/odata/sap/API_SALES_ORDER_SRV

# OpenWeather API Configuration
WEATHER_API_KEY=your-openweather-api-key
WEATHER_BASE_URL=https://api.openweathermap.org/data/2.5
```

### 3. Run the System

```bash
python main.py
```

The API will be available at `http://localhost:8000`

## 📚 API Documentation

Once running, access interactive API docs:
- Swagger UI: http://localhost:8000/docs
- ReDoc: http://localhost:8000/redoc

## 🔧 API Endpoints

### Main Query Endpoint

```bash
POST /query
{
  "query": "Show me recent sales orders",
  "context": {}
}
```

### Agent-Specific Endpoints

**SAP Agent:**
```bash
POST /sap/query
{
  "query": "Get sales order details for order 12345"
}
```

**Weather Agent:**
```bash
POST /weather/query
{
  "query": "What's the weather in San Francisco?"
}
```

### System Endpoints

```bash
GET /                # System info
GET /health          # Health check
GET /agents          # Available agents
GET /mcp/tools       # Available MCP tools
```

## 💡 Example Queries

### Single Agent Queries

**SAP:**
- "Show me recent sales orders"
- "Get details for sales order 12345"
- "List all sales orders from last week"

**Weather:**
- "What's the weather in New York?"
- "Give me a 5-day forecast for London"
- "Search for weather in San Francisco"

### Multi-Agent Queries

- "Show me sales orders and weather for delivery locations"
- "Get order data and check weather conditions for shipment"
- "Analyze sales orders and weather patterns"

## 🏛️ Project Structure

```
sap-mcp-system/
├── main.py                 # FastAPI host application
├── config.py              # Configuration management
├── orchestrator.py        # Multi-agent orchestrator
├── requirements.txt       # Python dependencies
├── .env.example          # Environment template
├── agents/
│   ├── __init__.py
│   ├── sap_agent.py      # SAP Business Hub agent
│   └── weather_agent.py  # Weather forecast agent
└── mcp/
    ├── __init__.py
    ├── client.py         # MCP client
    ├── sap_server.py     # SAP MCP server
    └── weather_server.py # Weather MCP server
```

## 🔄 How It Works

### End-to-End Flow

1. **User sends query** to FastAPI host
2. **Orchestrator analyzes intent** using OpenAI LLM
3. **Determines which agent(s)** to invoke
4. **Agent(s) process query**:
   - Use LLM to select appropriate MCP tools
   - MCP Client discovers and calls tools
   - MCP Server executes API calls
   - Results returned to agent
5. **Agent formats results** using LLM
6. **Orchestrator synthesizes** multi-agent results (if applicable)
7. **Final response** returned to user

### MCP Protocol Flow

```
Agent → MCP Client → list_tools() → MCP Server
                  ↓
      call_tool(name, params) → MCP Server → External API
                  ↓
              Response ← Results
```

## 🔐 Security Best Practices

- Never commit `.env` file
- Use environment variables for all secrets
- Rotate API keys regularly
- Use HTTPS in production
- Implement rate limiting
- Add authentication middleware

## 📊 Monitoring & Logging

The system includes comprehensive logging:

```python
# View logs
tail -f logs/app.log

# Log levels: DEBUG, INFO, WARNING, ERROR, CRITICAL
```

## 🧪 Testing

### Test Individual Components

**Test SAP Agent:**
```bash
curl -X POST http://localhost:8000/sap/query \
  -H "Content-Type: application/json" \
  -d '{"query": "Show sales orders"}'
```

**Test Weather Agent:**
```bash
curl -X POST http://localhost:8000/weather/query \
  -H "Content-Type: application/json" \
  -d '{"query": "Weather in Paris"}'
```

**Test Multi-Agent:**
```bash
curl -X POST http://localhost:8000/query \
  -H "Content-Type: application/json" \
  -d '{"query": "Get sales data and weather forecast"}'
```

## 🛠️ Customization

### Adding New Agents

1. Create agent in `agents/new_agent.py`:
```python
from agents.base_agent import BaseAgent

class NewAgent(BaseAgent):
    def __init__(self):
        # Initialize MCP server
        pass
    
    async def process(self, query, context):
        # Implementation
        pass
```

2. Add MCP server in `mcp/new_server.py`
3. Register in `orchestrator.py`

### Adding New MCP Tools

In your MCP server's `list_tools()`:
```python
{
    "name": "new_tool",
    "description": "Tool description",
    "parameters": {...}
}
```

## 🚨 Troubleshooting

### Common Issues

**Connection errors:**
- Check API keys in `.env`
- Verify network connectivity
- Check API endpoint URLs

**Agent not responding:**
- Check logs for errors
- Verify LLM API key
- Ensure all dependencies installed

**Tool not found:**
- Verify MCP server registered tools
- Check tool name spelling
- Review MCP client initialization

## 📈 Performance Optimization

- Use async operations throughout
- Implement caching for frequent queries
- Add connection pooling
- Use batch operations where possible
- Monitor API rate limits

## 🤝 Contributing

1. Fork the repository
2. Create feature branch
3. Make changes
4. Test thoroughly
5. Submit pull request

## 📄 License

MIT License - See LICENSE file

## 🆘 Support

For issues and questions:
- Check logs in `logs/` directory
- Review API documentation
- Check environment configuration
- Verify API credentials

## 🔗 Related Resources

- [SAP Business Hub API Documentation](https://api.sap.com)
- [OpenWeather API Documentation](https://openweathermap.org/api)
- [OpenAI API Documentation](https://platform.openai.com/docs)
- [FastAPI Documentation](https://fastapi.tiangolo.com)
- [Model Context Protocol](https://modelcontextprotocol.io)

## 🎯 Roadmap

- [ ] Add more agents (Salesforce, Google Calendar, etc.)
- [ ] Implement caching layer
- [ ] Add authentication system
- [ ] Create web UI dashboard
- [ ] Add batch processing
- [ ] Implement webhook support
- [ ] Add monitoring dashboard
- [ ] Create Docker deployment
