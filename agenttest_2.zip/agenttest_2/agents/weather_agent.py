"""
Weather Agent - Handles weather forecast operations with LLM intelligence
"""
import logging
import json
from typing import Dict, Any, Optional
from openai import AsyncOpenAI
from config import config
from mcp import MCPClient, WeatherMCPServer

logger = logging.getLogger(__name__)


class WeatherAgent:
    """
    Weather Agent that uses LLM to intelligently interact with Weather APIs
    through the MCP protocol
    """
    
    def __init__(self):
        self.name = "Weather Agent"
        self.description = "Handles weather forecast and location queries"
        
        # Initialize OpenAI client
        self.llm = AsyncOpenAI(api_key=config.openai.api_key)
        
        # Initialize MCP Server and Client
        self.mcp_server = WeatherMCPServer()
        self.mcp_client = MCPClient(self.mcp_server)
        
        logger.info(f"{self.name} initialized with {len(self.mcp_client.get_tools())} tools")
    
    async def process(self, query: str, context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Process a query using LLM and Weather tools
        
        Args:
            query: User query
            context: Additional context
            
        Returns:
            Processed result with LLM-formatted response
        """
        try:
            logger.info(f"Weather Agent processing query: {query}")
            
            # Step 1: Use LLM to determine which tool(s) to use
            tool_selection = await self._select_tools(query, context)
            
            if not tool_selection.get("needs_tools"):
                return {
                    "success": True,
                    "response": tool_selection.get("response"),
                    "agent": self.name
                }
            
            # Step 2: Execute the selected tools
            tool_results = await self._execute_tools(tool_selection.get("tools", []))
            
            # Step 3: Use LLM to format the results
            final_response = await self._format_response(query, tool_results, context)
            
            return {
                "success": True,
                "response": final_response,
                "tool_results": tool_results,
                "agent": self.name
            }
            
        except Exception as e:
            logger.error(f"Error in Weather Agent: {e}")
            return {
                "success": False,
                "error": str(e),
                "agent": self.name
            }
    
    async def _select_tools(self, query: str, context: Optional[Dict] = None) -> Dict[str, Any]:
        """Use LLM to select appropriate tools"""
        try:
            tools_description = self.mcp_client.get_tool_descriptions()
            
            prompt = f"""You are a weather assistant. Analyze the user's query and determine which weather tools to use.

Available Weather Tools:
{tools_description}

User Query: {query}

Context: {json.dumps(context) if context else 'None'}

Respond in JSON format:
{{
    "needs_tools": true/false,
    "response": "direct response if no tools needed",
    "tools": [
        {{
            "name": "tool_name",
            "params": {{"city": "location"}}
        }}
    ],
    "reasoning": "explanation of tool selection"
}}

If the query can be answered without tools, set needs_tools to false and provide a direct response.
If tools are needed, specify which tools and parameters to use.
For location-based queries, extract the city name from the query."""

            response = await self.llm.chat.completions.create(
                model=config.openai.model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.3,
                response_format={"type": "json_object"}
            )
            
            result = json.loads(response.choices[0].message.content)
            logger.info(f"Tool selection: {result.get('reasoning')}")
            
            return result
            
        except Exception as e:
            logger.error(f"Error selecting tools: {e}")
            return {
                "needs_tools": False,
                "response": "I encountered an error analyzing your weather request. Please try again."
            }
    
    async def _execute_tools(self, tool_calls: list) -> list:
        """Execute the selected tools"""
        results = []
        for tool_call in tool_calls:
            result = await self.mcp_client.call_tool(
                tool_call["name"],
                **tool_call.get("params", {})
            )
            results.append({
                "tool": tool_call["name"],
                "result": result
            })
        return results
    
    async def _format_response(
        self, 
        query: str, 
        tool_results: list,
        context: Optional[Dict] = None
    ) -> str:
        """Use LLM to format tool results into natural language"""
        try:
            prompt = f"""You are a helpful weather assistant. Format the weather data into a clear, friendly response.

Original Query: {query}

Weather Data:
{json.dumps(tool_results, indent=2)}

Context: {json.dumps(context) if context else 'None'}

Provide a clear, conversational response that:
1. Directly answers the user's query
2. Presents weather information in an easy-to-understand format
3. Includes relevant details (temperature, conditions, etc.)
4. Adds helpful context or recommendations if appropriate
5. If there are errors, explain them in a user-friendly way

Response:"""

            response = await self.llm.chat.completions.create(
                model=config.openai.model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.7
            )
            
            return response.choices[0].message.content
            
        except Exception as e:
            logger.error(f"Error formatting response: {e}")
            return f"Retrieved weather data but encountered an error formatting: {str(e)}"
    
    def get_capabilities(self) -> str:
        """Return agent capabilities description"""
        return f"""
{self.name} Capabilities:
- Get current weather for any location
- Provide 5-day weather forecasts
- Search for location coordinates
- Analyze weather patterns
- Provide weather-based recommendations
"""
