"""
Configuration management for the Multi-Agent MCP System
"""
import os
from dotenv import load_dotenv
from pydantic import BaseModel

# Load environment variables
load_dotenv()


class OpenAIConfig(BaseModel):
    """OpenAI LLM Configuration"""
    api_key: str
    model: str = "gpt-4"
    temperature: float = 0.7
    max_tokens: int = 2000


class SAPConfig(BaseModel):
    """SAP Business Hub Configuration"""
    api_key: str
    base_url: str
    timeout: int = 30


class WeatherConfig(BaseModel):
    """Weather API Configuration"""
    api_key: str
    base_url: str
    timeout: int = 10


class AppConfig(BaseModel):
    """Application Configuration"""
    host: str = "0.0.0.0"
    port: int = 8000
    log_level: str = "INFO"


class Config:
    """Main configuration class"""
    
    def __init__(self):
        # OpenAI Configuration
        self.openai = OpenAIConfig(
            api_key=os.getenv("OPENAI_API_KEY", ""),
            model=os.getenv("OPENAI_MODEL", "gpt-4"),
            temperature=float(os.getenv("OPENAI_TEMPERATURE", "0.7")),
            max_tokens=int(os.getenv("OPENAI_MAX_TOKENS", "2000"))
        )
        
        # SAP Configuration
        self.sap = SAPConfig(
            api_key=os.getenv("SAP_API_KEY", ""),
            base_url=os.getenv("SAP_BASE_URL", ""),
            timeout=int(os.getenv("SAP_TIMEOUT", "30"))
        )
        
        # Weather Configuration
        self.weather = WeatherConfig(
            api_key=os.getenv("WEATHER_API_KEY", ""),
            base_url=os.getenv("WEATHER_BASE_URL", ""),
            timeout=int(os.getenv("WEATHER_TIMEOUT", "10"))
        )
        
        # App Configuration
        self.app = AppConfig(
            host=os.getenv("HOST", "0.0.0.0"),
            port=int(os.getenv("PORT", "8000")),
            log_level=os.getenv("LOG_LEVEL", "INFO")
        )
    
    def validate(self):
        """Validate required configuration"""
        errors = []
        
        if not self.openai.api_key:
            errors.append("OPENAI_API_KEY is required")
        
        if not self.sap.api_key:
            errors.append("SAP_API_KEY is required")
        
        if not self.weather.api_key:
            errors.append("WEATHER_API_KEY is required")
        
        if errors:
            raise ValueError(f"Configuration errors: {', '.join(errors)}")
        
        return True


# Global configuration instance
config = Config()
