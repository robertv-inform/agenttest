"""
Main FastAPI Application - Host for Multi-Agent MCP System
"""
import logging
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, Dict, Any
import uvicorn

from config import config
from orchestrator import Orchestrator

# Configure logging
logging.basicConfig(
    level=getattr(logging, config.app.log_level),
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Initialize FastAPI app
app = FastAPI(
    title="Multi-Agent MCP System",
    description="Production-ready multi-agent system with SAP and Weather APIs using MCP protocol",
    version="1.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize orchestrator
orchestrator: Optional[Orchestrator] = None


class QueryRequest(BaseModel):
    """Request model for queries"""
    query: str
    context: Optional[Dict[str, Any]] = None


class QueryResponse(BaseModel):
    """Response model for queries"""
    success: bool
    response: str
    agent_results: Optional[Dict[str, Any]] = None
    error: Optional[str] = None


@app.on_event("startup")
async def startup_event():
    """Initialize system on startup"""
    global orchestrator
    
    try:
        logger.info("Starting Multi-Agent MCP System...")
        
        # Validate configuration
        config.validate()
        logger.info("Configuration validated successfully")
        
        # Initialize orchestrator
        orchestrator = Orchestrator()
        logger.info("Orchestrator initialized successfully")
        
        logger.info("System startup complete!")
        
    except Exception as e:
        logger.error(f"Failed to start system: {e}")
        raise


@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "service": "Multi-Agent MCP System",
        "status": "running",
        "version": "1.0.0",
        "agents": list(orchestrator.agents.keys()) if orchestrator else []
    }


@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "orchestrator": orchestrator is not None,
        "agents": len(orchestrator.agents) if orchestrator else 0
    }


@app.get("/agents")
async def get_agents():
    """Get available agents and their capabilities"""
    if not orchestrator:
        raise HTTPException(status_code=503, detail="Orchestrator not initialized")
    
    return {
        "agents": orchestrator.get_available_agents()
    }


@app.post("/query", response_model=QueryResponse)
async def process_query(request: QueryRequest):
    """
    Process a user query through the multi-agent system
    
    Examples:
    - "Show me recent sales orders"
    - "What's the weather in San Francisco?"
    - "Get sales orders and weather for delivery locations"
    """
    if not orchestrator:
        raise HTTPException(status_code=503, detail="Orchestrator not initialized")
    
    try:
        logger.info(f"Processing query: {request.query}")
        
        result = await orchestrator.process_query(request.query, request.context)
        
        return QueryResponse(
            success=result.get("success", False),
            response=result.get("response", ""),
            agent_results=result.get("agent_results"),
            error=result.get("error")
        )
        
    except Exception as e:
        logger.error(f"Error processing query: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/sap/query")
async def sap_query(request: QueryRequest):
    """Direct SAP agent query endpoint"""
    if not orchestrator:
        raise HTTPException(status_code=503, detail="Orchestrator not initialized")
    
    try:
        sap_agent = orchestrator.agents.get("sap")
        if not sap_agent:
            raise HTTPException(status_code=404, detail="SAP agent not found")
        
        result = await sap_agent.process(request.query, request.context)
        
        return QueryResponse(
            success=result.get("success", False),
            response=result.get("response", ""),
            agent_results={"sap": result},
            error=result.get("error")
        )
        
    except Exception as e:
        logger.error(f"Error in SAP query: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/weather/query")
async def weather_query(request: QueryRequest):
    """Direct Weather agent query endpoint"""
    if not orchestrator:
        raise HTTPException(status_code=503, detail="Orchestrator not initialized")
    
    try:
        weather_agent = orchestrator.agents.get("weather")
        if not weather_agent:
            raise HTTPException(status_code=404, detail="Weather agent not found")
        
        result = await weather_agent.process(request.query, request.context)
        
        return QueryResponse(
            success=result.get("success", False),
            response=result.get("response", ""),
            agent_results={"weather": result},
            error=result.get("error")
        )
        
    except Exception as e:
        logger.error(f"Error in weather query: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/mcp/tools")
async def get_mcp_tools():
    """Get all available MCP tools from all agents"""
    if not orchestrator:
        raise HTTPException(status_code=503, detail="Orchestrator not initialized")
    
    all_tools = {}
    
    for agent_name, agent in orchestrator.agents.items():
        tools = agent.mcp_client.get_tools()
        all_tools[agent_name] = [
            {
                "name": tool.name,
                "description": tool.description,
                "parameters": tool.parameters
            }
            for tool in tools
        ]
    
    return {"tools": all_tools}


if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host=config.app.host,
        port=config.app.port,
        reload=False,
        log_level=config.app.log_level.lower()
    )
