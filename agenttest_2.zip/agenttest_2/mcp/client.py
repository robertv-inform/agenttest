"""
MCP Client - Handles communication with MCP Servers
"""
import httpx
import logging
from typing import Dict, List, Any, Optional
from pydantic import BaseModel

logger = logging.getLogger(__name__)


class MCPTool(BaseModel):
    """MCP Tool definition"""
    name: str
    description: str
    parameters: Dict[str, Any]


class MCPClient:
    """
    MCP Client for communicating with MCP Servers
    Implements the Model Context Protocol for tool discovery and execution
    """
    
    def __init__(self, server_instance):
        """
        Initialize MCP Client with a server instance
        
        Args:
            server_instance: Instance of MCP Server (SAPMCPServer or WeatherMCPServer)
        """
        self.server = server_instance
        self.tools: List[MCPTool] = []
        self._discover_tools()
    
    def _discover_tools(self):
        """Discover available tools from the MCP server"""
        try:
            tools_data = self.server.list_tools()
            self.tools = [MCPTool(**tool) for tool in tools_data]
            logger.info(f"Discovered {len(self.tools)} tools from MCP server")
        except Exception as e:
            logger.error(f"Error discovering tools: {e}")
            self.tools = []
    
    def get_tools(self) -> List[MCPTool]:
        """Get list of available tools"""
        return self.tools
    
    def get_tool_descriptions(self) -> str:
        """Get formatted tool descriptions for LLM"""
        if not self.tools:
            return "No tools available"
        
        descriptions = []
        for tool in self.tools:
            params = ", ".join([f"{k}: {v.get('type', 'any')}" for k, v in tool.parameters.items()])
            descriptions.append(f"- {tool.name}({params}): {tool.description}")
        
        return "\n".join(descriptions)
    
    async def call_tool(self, tool_name: str, **kwargs) -> Dict[str, Any]:
        """
        Call a tool on the MCP server
        
        Args:
            tool_name: Name of the tool to call
            **kwargs: Tool parameters
            
        Returns:
            Tool execution result
        """
        try:
            logger.info(f"Calling tool: {tool_name} with params: {kwargs}")
            
            # Find the tool
            tool = next((t for t in self.tools if t.name == tool_name), None)
            if not tool:
                return {
                    "success": False,
                    "error": f"Tool '{tool_name}' not found"
                }
            
            # Call the tool on the server
            result = await self.server.call_tool(tool_name, kwargs)
            
            logger.info(f"Tool {tool_name} executed successfully")
            return result
            
        except Exception as e:
            logger.error(f"Error calling tool {tool_name}: {e}")
            return {
                "success": False,
                "error": str(e)
            }
    
    async def execute_tool_chain(self, tool_calls: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Execute multiple tool calls in sequence
        
        Args:
            tool_calls: List of tool calls [{"name": "tool_name", "params": {...}}, ...]
            
        Returns:
            List of results
        """
        results = []
        for call in tool_calls:
            result = await self.call_tool(call["name"], **call.get("params", {}))
            results.append({
                "tool": call["name"],
                "result": result
            })
        return results
