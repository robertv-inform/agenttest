"""
SAP MCP Server - Handles SAP Business Hub O2C API operations
"""
import httpx
import logging
from typing import Dict, List, Any, Optional
from config import config

logger = logging.getLogger(__name__)


class SAPMCPServer:
    """
    MCP Server for SAP Business Hub API
    Provides tools for sales order operations
    """
    
    def __init__(self):
        self.api_key = config.sap.api_key
        self.base_url = config.sap.base_url
        self.timeout = config.sap.timeout
        
        if not self.api_key:
            logger.warning("SAP API Key not configured")
    
    def list_tools(self) -> List[Dict[str, Any]]:
        """List available SAP tools"""
        return [
            {
                "name": "get_sales_orders",
                "description": "Retrieve list of sales orders from SAP",
                "parameters": {
                    "top": {
                        "type": "integer",
                        "description": "Number of records to return (default: 10)",
                        "required": False
                    },
                    "filter": {
                        "type": "string",
                        "description": "OData filter string",
                        "required": False
                    }
                }
            },
            {
                "name": "get_order_details",
                "description": "Get detailed information about a specific sales order",
                "parameters": {
                    "order_id": {
                        "type": "string",
                        "description": "Sales Order ID",
                        "required": True
                    }
                }
            },
            {
                "name": "create_sales_order",
                "description": "Create a new sales order",
                "parameters": {
                    "customer_id": {
                        "type": "string",
                        "description": "Customer ID",
                        "required": True
                    },
                    "items": {
                        "type": "array",
                        "description": "Order items",
                        "required": True
                    }
                }
            }
        ]
    
    async def call_tool(self, tool_name: str, params: Dict[str, Any]) -> Dict[str, Any]:
        """Execute a tool"""
        try:
            if tool_name == "get_sales_orders":
                return await self._get_sales_orders(**params)
            elif tool_name == "get_order_details":
                return await self._get_order_details(**params)
            elif tool_name == "create_sales_order":
                return await self._create_sales_order(**params)
            else:
                return {
                    "success": False,
                    "error": f"Unknown tool: {tool_name}"
                }
        except Exception as e:
            logger.error(f"Error executing {tool_name}: {e}")
            return {
                "success": False,
                "error": str(e)
            }
    
    async def _get_sales_orders(self, top: int = 10, filter: Optional[str] = None) -> Dict[str, Any]:
        """Get sales orders from SAP"""
        try:
            headers = {
                "APIKey": self.api_key,
                "Accept": "application/json"
            }
            
            # Build query parameters
            params = {"$top": top}
            if filter:
                params["$filter"] = filter
            
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                url = f"{self.base_url}/A_SalesOrder"
                logger.info(f"Fetching sales orders from SAP: {url}")
                
                response = await client.get(url, headers=headers, params=params)
                response.raise_for_status()
                
                data = response.json()
                orders = data.get("d", {}).get("results", [])
                
                return {
                    "success": True,
                    "data": {
                        "count": len(orders),
                        "orders": orders
                    }
                }
                
        except httpx.HTTPStatusError as e:
            logger.error(f"SAP API HTTP error: {e.response.status_code} - {e.response.text}")
            return {
                "success": False,
                "error": f"SAP API error: {e.response.status_code}",
                "details": e.response.text
            }
        except Exception as e:
            logger.error(f"Error fetching sales orders: {e}")
            return {
                "success": False,
                "error": str(e)
            }
    
    async def _get_order_details(self, order_id: str) -> Dict[str, Any]:
        """Get details of a specific sales order"""
        try:
            headers = {
                "APIKey": self.api_key,
                "Accept": "application/json"
            }
            
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                url = f"{self.base_url}/A_SalesOrder('{order_id}')"
                logger.info(f"Fetching order details: {url}")
                
                response = await client.get(url, headers=headers)
                response.raise_for_status()
                
                data = response.json()
                order = data.get("d", {})
                
                return {
                    "success": True,
                    "data": order
                }
                
        except httpx.HTTPStatusError as e:
            return {
                "success": False,
                "error": f"Order not found or API error: {e.response.status_code}"
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    async def _create_sales_order(self, customer_id: str, items: List[Dict]) -> Dict[str, Any]:
        """Create a new sales order"""
        try:
            headers = {
                "APIKey": self.api_key,
                "Accept": "application/json",
                "Content-Type": "application/json"
            }
            
            payload = {
                "SoldToParty": customer_id,
                "to_Item": {
                    "results": items
                }
            }
            
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                url = f"{self.base_url}/A_SalesOrder"
                logger.info(f"Creating sales order: {url}")
                
                response = await client.post(url, headers=headers, json=payload)
                response.raise_for_status()
                
                data = response.json()
                
                return {
                    "success": True,
                    "data": data.get("d", {})
                }
                
        except httpx.HTTPStatusError as e:
            return {
                "success": False,
                "error": f"Failed to create order: {e.response.status_code}",
                "details": e.response.text
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
