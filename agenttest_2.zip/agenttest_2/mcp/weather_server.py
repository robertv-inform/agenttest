"""
Weather MCP Server - Handles OpenWeather API operations
"""
import httpx
import logging
from typing import Dict, List, Any, Optional
from config import config

logger = logging.getLogger(__name__)


class WeatherMCPServer:
    """
    MCP Server for OpenWeather API
    Provides tools for weather forecast operations
    """
    
    def __init__(self):
        self.api_key = config.weather.api_key
        self.base_url = config.weather.base_url
        self.timeout = config.weather.timeout
        
        if not self.api_key:
            logger.warning("Weather API Key not configured")
    
    def list_tools(self) -> List[Dict[str, Any]]:
        """List available weather tools"""
        return [
            {
                "name": "get_current_weather",
                "description": "Get current weather for a location",
                "parameters": {
                    "city": {
                        "type": "string",
                        "description": "City name",
                        "required": False
                    },
                    "lat": {
                        "type": "number",
                        "description": "Latitude",
                        "required": False
                    },
                    "lon": {
                        "type": "number",
                        "description": "Longitude",
                        "required": False
                    }
                }
            },
            {
                "name": "get_forecast",
                "description": "Get 5-day weather forecast for a location",
                "parameters": {
                    "city": {
                        "type": "string",
                        "description": "City name",
                        "required": False
                    },
                    "lat": {
                        "type": "number",
                        "description": "Latitude",
                        "required": False
                    },
                    "lon": {
                        "type": "number",
                        "description": "Longitude",
                        "required": False
                    }
                }
            },
            {
                "name": "search_location",
                "description": "Search for location coordinates by city name",
                "parameters": {
                    "city": {
                        "type": "string",
                        "description": "City name to search",
                        "required": True
                    }
                }
            }
        ]
    
    async def call_tool(self, tool_name: str, params: Dict[str, Any]) -> Dict[str, Any]:
        """Execute a tool"""
        try:
            if tool_name == "get_current_weather":
                return await self._get_current_weather(**params)
            elif tool_name == "get_forecast":
                return await self._get_forecast(**params)
            elif tool_name == "search_location":
                return await self._search_location(**params)
            else:
                return {
                    "success": False,
                    "error": f"Unknown tool: {tool_name}"
                }
        except Exception as e:
            logger.error(f"Error executing {tool_name}: {e}")
            return {
                "success": False,
                "error": str(e)
            }
    
    async def _get_current_weather(
        self, 
        city: Optional[str] = None,
        lat: Optional[float] = None,
        lon: Optional[float] = None
    ) -> Dict[str, Any]:
        """Get current weather"""
        try:
            params = {"appid": self.api_key, "units": "metric"}
            
            if city:
                params["q"] = city
            elif lat is not None and lon is not None:
                params["lat"] = lat
                params["lon"] = lon
            else:
                return {
                    "success": False,
                    "error": "Either city or lat/lon must be provided"
                }
            
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                url = f"{self.base_url}/weather"
                logger.info(f"Fetching current weather: {url}")
                
                response = await client.get(url, params=params)
                response.raise_for_status()
                
                data = response.json()
                
                # Format the response
                weather_data = {
                    "location": data.get("name"),
                    "country": data.get("sys", {}).get("country"),
                    "temperature": data.get("main", {}).get("temp"),
                    "feels_like": data.get("main", {}).get("feels_like"),
                    "humidity": data.get("main", {}).get("humidity"),
                    "description": data.get("weather", [{}])[0].get("description"),
                    "wind_speed": data.get("wind", {}).get("speed"),
                    "coordinates": {
                        "lat": data.get("coord", {}).get("lat"),
                        "lon": data.get("coord", {}).get("lon")
                    }
                }
                
                return {
                    "success": True,
                    "data": weather_data
                }
                
        except httpx.HTTPStatusError as e:
            logger.error(f"Weather API error: {e.response.status_code}")
            return {
                "success": False,
                "error": f"Weather API error: {e.response.status_code}",
                "details": e.response.text
            }
        except Exception as e:
            logger.error(f"Error fetching weather: {e}")
            return {
                "success": False,
                "error": str(e)
            }
    
    async def _get_forecast(
        self,
        city: Optional[str] = None,
        lat: Optional[float] = None,
        lon: Optional[float] = None
    ) -> Dict[str, Any]:
        """Get 5-day forecast"""
        try:
            params = {"appid": self.api_key, "units": "metric"}
            
            if city:
                params["q"] = city
            elif lat is not None and lon is not None:
                params["lat"] = lat
                params["lon"] = lon
            else:
                return {
                    "success": False,
                    "error": "Either city or lat/lon must be provided"
                }
            
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                url = f"{self.base_url}/forecast"
                logger.info(f"Fetching forecast: {url}")
                
                response = await client.get(url, params=params)
                response.raise_for_status()
                
                data = response.json()
                
                # Format forecast data
                forecasts = []
                for item in data.get("list", [])[:8]:  # Next 24 hours (3-hour intervals)
                    forecasts.append({
                        "datetime": item.get("dt_txt"),
                        "temperature": item.get("main", {}).get("temp"),
                        "feels_like": item.get("main", {}).get("feels_like"),
                        "description": item.get("weather", [{}])[0].get("description"),
                        "humidity": item.get("main", {}).get("humidity"),
                        "wind_speed": item.get("wind", {}).get("speed"),
                        "rain_probability": item.get("pop", 0) * 100
                    })
                
                return {
                    "success": True,
                    "data": {
                        "location": data.get("city", {}).get("name"),
                        "country": data.get("city", {}).get("country"),
                        "forecasts": forecasts
                    }
                }
                
        except httpx.HTTPStatusError as e:
            return {
                "success": False,
                "error": f"Weather API error: {e.response.status_code}"
            }
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
    
    async def _search_location(self, city: str) -> Dict[str, Any]:
        """Search for location by city name"""
        try:
            params = {
                "q": city,
                "limit": 5,
                "appid": self.api_key
            }
            
            async with httpx.AsyncClient(timeout=self.timeout) as client:
                url = "http://api.openweathermap.org/geo/1.0/direct"
                logger.info(f"Searching location: {city}")
                
                response = await client.get(url, params=params)
                response.raise_for_status()
                
                data = response.json()
                
                locations = []
                for loc in data:
                    locations.append({
                        "name": loc.get("name"),
                        "country": loc.get("country"),
                        "state": loc.get("state"),
                        "lat": loc.get("lat"),
                        "lon": loc.get("lon")
                    })
                
                return {
                    "success": True,
                    "data": locations
                }
                
        except Exception as e:
            return {
                "success": False,
                "error": str(e)
            }
