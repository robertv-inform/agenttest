"""
Orchestrator - Coordinates multiple agents and manages workflow
"""
import logging
import json
import asyncio
from typing import Dict, Any, List, Optional
from openai import AsyncOpenAI
from config import config
from agents import SAPAgent, WeatherAgent

logger = logging.getLogger(__name__)


class Orchestrator:
    """
    Orchestrator coordinates multiple agents to handle complex queries
    Uses LLM to determine intent and route to appropriate agents
    """
    
    def __init__(self):
        self.llm = AsyncOpenAI(api_key=config.openai.api_key)
        
        # Initialize agents
        self.agents = {
            "sap": SAPAgent(),
            "weather": WeatherAgent()
        }
        
        logger.info("Orchestrator initialized with agents: " + ", ".join(self.agents.keys()))
    
    async def process_query(self, query: str, context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Process a user query by determining intent and routing to appropriate agents
        
        Args:
            query: User query
            context: Optional context
            
        Returns:
            Orchestrated response from one or more agents
        """
        try:
            logger.info(f"Orchestrator processing query: {query}")
            
            # Step 1: Analyze intent and determine which agent(s) to use
            intent_analysis = await self._analyze_intent(query, context)
            
            if not intent_analysis.get("success"):
                return {
                    "success": False,
                    "error": "Failed to analyze query intent",
                    "response": "I'm having trouble understanding your request. Could you please rephrase it?"
                }
            
            agents_needed = intent_analysis.get("agents", [])
            
            if not agents_needed:
                return {
                    "success": True,
                    "response": intent_analysis.get("direct_response", "I'm not sure how to help with that."),
                    "intent": intent_analysis
                }
            
            # Step 2: Execute agent(s) in parallel or sequence based on dependencies
            if len(agents_needed) == 1:
                # Single agent execution
                result = await self._execute_single_agent(agents_needed[0], query, context)
            else:
                # Multi-agent execution
                result = await self._execute_multi_agent(agents_needed, query, context, intent_analysis)
            
            return result
            
        except Exception as e:
            logger.error(f"Error in orchestrator: {e}")
            return {
                "success": False,
                "error": str(e),
                "response": "I encountered an error processing your request. Please try again."
            }
    
    async def _analyze_intent(self, query: str, context: Optional[Dict] = None) -> Dict[str, Any]:
        """Analyze query intent using LLM"""
        try:
            # Get agent capabilities
            capabilities = {
                name: agent.get_capabilities() 
                for name, agent in self.agents.items()
            }
            
            prompt = f"""You are an intelligent orchestrator. Analyze the user's query and determine which agents should handle it.

Available Agents and Their Capabilities:
{json.dumps(capabilities, indent=2)}

User Query: {query}

Context: {json.dumps(context) if context else 'None'}

Analyze the query and respond in JSON format:
{{
    "success": true,
    "intent": "brief description of user intent",
    "agents": ["agent_name1", "agent_name2"],
    "needs_coordination": true/false,
    "execution_plan": "description of how agents should work together",
    "direct_response": "response if no agents needed"
}}

Rules:
1. If query is about SAP, sales orders, or business operations → use "sap" agent
2. If query is about weather or forecast → use "weather" agent
3. If query involves both → include both agents and set needs_coordination to true
4. If query is unrelated to available agents → set agents to [] and provide direct_response
5. Be specific about what each agent should do"""

            response = await self.llm.chat.completions.create(
                model=config.openai.model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.3,
                response_format={"type": "json_object"}
            )
            
            result = json.loads(response.choices[0].message.content)
            logger.info(f"Intent analysis: {result.get('intent')}")
            logger.info(f"Agents selected: {result.get('agents')}")
            
            return result
            
        except Exception as e:
            logger.error(f"Error analyzing intent: {e}")
            return {
                "success": False,
                "error": str(e)
            }
    
    async def _execute_single_agent(
        self, 
        agent_name: str, 
        query: str, 
        context: Optional[Dict] = None
    ) -> Dict[str, Any]:
        """Execute a single agent"""
        try:
            agent = self.agents.get(agent_name)
            if not agent:
                return {
                    "success": False,
                    "error": f"Agent '{agent_name}' not found"
                }
            
            result = await agent.process(query, context)
            return result
            
        except Exception as e:
            logger.error(f"Error executing agent {agent_name}: {e}")
            return {
                "success": False,
                "error": str(e),
                "agent": agent_name
            }
    
    async def _execute_multi_agent(
        self,
        agent_names: List[str],
        query: str,
        context: Optional[Dict],
        intent_analysis: Dict[str, Any]
    ) -> Dict[str, Any]:
        """Execute multiple agents and coordinate their results"""
        try:
            logger.info(f"Executing multi-agent workflow: {agent_names}")
            
            # Execute agents in parallel
            tasks = []
            for agent_name in agent_names:
                agent = self.agents.get(agent_name)
                if agent:
                    tasks.append(agent.process(query, context))
            
            agent_results = await asyncio.gather(*tasks, return_exceptions=True)
            
            # Combine results
            combined_results = {}
            for agent_name, result in zip(agent_names, agent_results):
                if isinstance(result, Exception):
                    combined_results[agent_name] = {
                        "success": False,
                        "error": str(result)
                    }
                else:
                    combined_results[agent_name] = result
            
            # Use LLM to synthesize results
            final_response = await self._synthesize_results(
                query,
                combined_results,
                intent_analysis,
                context
            )
            
            return {
                "success": True,
                "response": final_response,
                "agent_results": combined_results,
                "multi_agent": True
            }
            
        except Exception as e:
            logger.error(f"Error in multi-agent execution: {e}")
            return {
                "success": False,
                "error": str(e)
            }
    
    async def _synthesize_results(
        self,
        query: str,
        agent_results: Dict[str, Any],
        intent_analysis: Dict[str, Any],
        context: Optional[Dict] = None
    ) -> str:
        """Synthesize results from multiple agents into a coherent response"""
        try:
            prompt = f"""You are an intelligent assistant synthesizing information from multiple sources.

Original Query: {query}

Intent: {intent_analysis.get('intent')}

Execution Plan: {intent_analysis.get('execution_plan')}

Results from Agents:
{json.dumps(agent_results, indent=2)}

Context: {json.dumps(context) if context else 'None'}

Create a comprehensive, well-organized response that:
1. Directly addresses the user's original query
2. Integrates information from all agents seamlessly
3. Presents data in a logical, easy-to-understand format
4. Highlights key insights and connections between different data sources
5. Uses a professional yet conversational tone
6. If any agents failed, handle errors gracefully

Response:"""

            response = await self.llm.chat.completions.create(
                model=config.openai.model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.7,
                max_tokens=config.openai.max_tokens
            )
            
            return response.choices[0].message.content
            
        except Exception as e:
            logger.error(f"Error synthesizing results: {e}")
            
            # Fallback: Simple concatenation
            responses = []
            for agent_name, result in agent_results.items():
                if result.get("success"):
                    responses.append(f"{agent_name.upper()} Agent:\n{result.get('response')}")
            
            return "\n\n".join(responses) if responses else "Error synthesizing results."
    
    def get_available_agents(self) -> Dict[str, str]:
        """Get list of available agents and their capabilities"""
        return {
            name: agent.get_capabilities()
            for name, agent in self.agents.items()
        }
