"""
Test Script for Multi-Agent MCP System
"""
import asyncio
import httpx
import json


async def test_system():
    """Test the multi-agent system"""
    base_url = "http://localhost:8000"
    
    print("=" * 60)
    print("Multi-Agent MCP System Test Script")
    print("=" * 60)
    
    async with httpx.AsyncClient() as client:
        # Test 1: Health check
        print("\n1. Testing Health Check...")
        try:
            response = await client.get(f"{base_url}/health")
            print(f"   Status: {response.status_code}")
            print(f"   Response: {json.dumps(response.json(), indent=2)}")
        except Exception as e:
            print(f"   Error: {e}")
        
        # Test 2: Get available agents
        print("\n2. Testing Available Agents...")
        try:
            response = await client.get(f"{base_url}/agents")
            print(f"   Status: {response.status_code}")
            agents = response.json()
            print(f"   Found {len(agents.get('agents', {}))} agents")
        except Exception as e:
            print(f"   Error: {e}")
        
        # Test 3: Get MCP tools
        print("\n3. Testing MCP Tools Discovery...")
        try:
            response = await client.get(f"{base_url}/mcp/tools")
            print(f"   Status: {response.status_code}")
            tools = response.json()
            for agent, agent_tools in tools.get("tools", {}).items():
                print(f"   {agent.upper()} Agent: {len(agent_tools)} tools")
                for tool in agent_tools:
                    print(f"      - {tool['name']}: {tool['description']}")
        except Exception as e:
            print(f"   Error: {e}")
        
        # Test 4: SAP Agent query
        print("\n4. Testing SAP Agent...")
        try:
            response = await client.post(
                f"{base_url}/sap/query",
                json={"query": "Show me recent sales orders"}
            )
            print(f"   Status: {response.status_code}")
            result = response.json()
            print(f"   Success: {result.get('success')}")
            print(f"   Response: {result.get('response')[:200]}...")
        except Exception as e:
            print(f"   Error: {e}")
        
        # Test 5: Weather Agent query
        print("\n5. Testing Weather Agent...")
        try:
            response = await client.post(
                f"{base_url}/weather/query",
                json={"query": "What's the weather in San Francisco?"}
            )
            print(f"   Status: {response.status_code}")
            result = response.json()
            print(f"   Success: {result.get('success')}")
            print(f"   Response: {result.get('response')[:200]}...")
        except Exception as e:
            print(f"   Error: {e}")
        
        # Test 6: Multi-agent query
        print("\n6. Testing Multi-Agent Orchestration...")
        try:
            response = await client.post(
                f"{base_url}/query",
                json={"query": "Get sales order data and weather information"}
            )
            print(f"   Status: {response.status_code}")
            result = response.json()
            print(f"   Success: {result.get('success')}")
            print(f"   Response: {result.get('response')[:200]}...")
            if result.get('agent_results'):
                print(f"   Agents used: {list(result['agent_results'].keys())}")
        except Exception as e:
            print(f"   Error: {e}")
    
    print("\n" + "=" * 60)
    print("Test Complete!")
    print("=" * 60)


if __name__ == "__main__":
    print("\nMake sure the server is running: python main.py")
    print("Press Enter to start tests...")
    input()
    
    asyncio.run(test_system())
