# Candidate Evaluation Service

This microservice evaluates candidate certification matches against job targets.

Features:

- LangChain-based agentic AI orchestration
- OpenAI embeddings and GPT-4o fallback
- Elasticsearch vector database for caching
- FastAPI for REST APIs
- Configurable for multi-tenancy and scalable workloads

Run with Docker Compose:

    docker-compose up --build

Post example JSON payload to /evaluate to get results.
