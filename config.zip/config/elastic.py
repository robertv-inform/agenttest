from elasticsearch import AsyncElasticsearch
from config import settings

es_client = AsyncElasticsearch(settings.ES_URL)

def build_knn_query(field, vector, k, num_candidates, tenant):
    return {
        "size": k,
        "query": {
            "bool": {
                "filter": {"term": {"tenant": tenant}},
                "must": {
                    "knn": {
                        field: {
                            "vector": vector,
                            "k": k,
                            "num_candidates": num_candidates
                        }
                    }
                }
            }
        }
    }
