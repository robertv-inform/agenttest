import os
import httpx

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
OPENAI_CHAT_URL = "https://api.openai.com/v1/chat/completions"
OPENAI_EMBED_URL = "https://api.openai.com/v1/embeddings"

class OpenAIClient:
    async def chat(self, prompt, model="gpt-4o-mini", max_tokens=64):
        headers = {
            "Authorization": f"Bearer {OPENAI_API_KEY}",
            "Content-Type": "application/json"
        }
        json_data = {
            "model": model,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": max_tokens,
            "temperature": 0.1
        }
        async with httpx.AsyncClient() as client:
            r = await client.post(OPENAI_CHAT_URL, headers=headers, json=json_data)
            r.raise_for_status()
            resp = r.json()
            return resp['choices'][0]['message']['content']

    async def embed(self, text, model="text-embedding-3-large"):
        headers = {"Authorization": f"Bearer {OPENAI_API_KEY}"}
        json_data = {"input": text, "model": model}
        async with httpx.AsyncClient() as client:
            r = await client.post(OPENAI_EMBED_URL, headers=headers, json=json_data)
            r.raise_for_status()
            resp = r.json()
            return resp['data'][0]['embedding']
