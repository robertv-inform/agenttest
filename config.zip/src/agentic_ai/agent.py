from langchain.agents import initialize_agent, Tool
from langchain.chat_models import ChatOpenAI
from mcp.mcp_registry import MCPRegistry

class CertificationAgent:
    def __init__(self, openai_model="gpt-4o-mini", verbose=False):
        self.registry = MCPRegistry()
        self.llm = ChatOpenAI(model_name=openai_model, temperature=0)
        self.verbose = verbose

    def register_tools(self, tools):
        for name, tool in tools.items():
            self.registry.register(name, tool)

    async def evaluate(self, tenant, targets, candidates):
        # Build Tool list from MCP Registry for LangChain AgentExecutor if needed
        tools = [Tool(name=name, func=tool_func, description=f"Tool {name}")
                 for name, tool in self.registry.tools.items()
                 for tool_func in [lambda *args, **kwargs: self.registry.call(name, "_arun", *args, **kwargs)]]

        # For simplicity, just run the pipeline evaluate using MCP tools
        pipeline = self.registry.tools.get('pipeline')
        if pipeline:
            result = await pipeline.evaluate(tenant, targets, candidates)
            if self.verbose:
                print(f"Evaluation result: {result}")
            return result
        else:
            raise Exception("Pipeline tool not registered in MCP Registry.")
