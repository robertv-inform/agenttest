from fastapi import FastAPI
from pydantic import BaseModel
from typing import List, Dict
from agentic_ai.agent import CertificationAgent
from mcp.tools import (  # Import your tools here
    ESSearchTool,
    ESCacheTool,
    GPTTool,
    LoggerTool
)
from services.pipeline import EvaluationPipeline

app = FastAPI(title="Candidate Evaluation Service")

# Define the Pydantic request model
class EvalRequest(BaseModel):
    tenant: str
    target_cert: List[str]
    source_cert: Dict[str, List[str]]

# Initialize agent and register all MCP tools including pipeline
agent = CertificationAgent(verbose=True)
pipeline = EvaluationPipeline()

tools = {
    "es_search": ESSearchTool(),
    "es_cache": ESCacheTool(),
    "gpt": GPTTool(),
    "logger": LoggerTool(),
    "pipeline": pipeline
}

agent.register_tools(tools)

@app.post("/evaluate")
async def evaluate_route(req: EvalRequest):
    result = await agent.evaluate(req.tenant, req.target_cert, req.source_cert)
    return {"results": result}
