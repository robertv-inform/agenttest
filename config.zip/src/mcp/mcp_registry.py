class MCPRegistry:
    def __init__(self):
        self.tools = {}

    def register(self, name, tool):
        self.tools[name] = tool

    async def call(self, name, method, **kwargs):
        tool = self.tools.get(name)
        if not tool:
            raise Exception(f"Tool {name} not found")
        func = getattr(tool, method)
        if callable(func):
            if callable(getattr(func, "__await__", None)):
                return await func(**kwargs)
            else:
                return func(**kwargs)
