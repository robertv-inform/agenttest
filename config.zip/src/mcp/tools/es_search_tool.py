from utils.elastic import es_client, build_knn_query
from config import settings

class ESSearchTool:
    def __init__(self):
        self.es = es_client
        self.index = settings.ES_INDEX_REQUIREMENTS

    async def topk(self, vector: list[float], tenant: str, k=8):
        body = build_knn_query("vec", vector, k, k*8, tenant)
        resp = await self.es.search(index=self.index, body=body)
        hits = resp['hits']['hits']
        return [{"score": h["_score"], "source": h["_source"]} for h in hits]
