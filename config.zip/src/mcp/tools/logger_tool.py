class LoggerTool:
    async def log(self, message: str):
        print(f"[LOGGER] {message}")
        return True
