def generate_explanation(matched, related, missing, method="normal", gpt_exp=None):
    exp = f"Matched: {', '.join(matched) or 'None'}; Related: {', '.join(related) or 'None'}; Missing: {', '.join(missing) or 'None'}."
    if method == "gpt" and gpt_exp is not None:
        exp += f" GPT explanation: {gpt_exp}"
    return exp
