import numpy as np

def cosine_similarity(a, b):
    a = np.array(a)
    b = np.array(b)
    return float(np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b) + 1e-8))

def classify_score(score: float):
    if score >= 0.9:
        return "exact"
    elif score >= 0.5:
        return "related"
    else:
        return "no_match"
