from mcp.mcp_registry import MCPRegistry
from mcp.tools.es_search_tool import ESSearchTool
from mcp.tools.es_cache_tool import ESCacheTool
from mcp.tools.gpt_tool import GPTTool
from services.matcher import cosine_similarity, classify_score
from services.preprocess import normalize_list
from services.explanation import generate_explanation
from utils.embedding import fake_embedding
import asyncio

class EvaluationPipeline:
    def __init__(self):
        self.registry = MCPRegistry()
        self.registry.register("es_search", ESSearchTool())
        self.registry.register("es_cache", ESCacheTool())
        self.registry.register("gpt", GPTTool())

    async def evaluate_cert(self, tenant, cert, candidate_certs):
        # Normalize
        cert_norm = cert.lower()
        candidate_certs_norm = [c.lower() for c in candidate_certs]

        # Embed query
        query_vec = fake_embedding(cert_norm)

        # 1. Cache check (ES)
        cache_hit = await self.registry.call("es_cache", "query_cache", tenant=tenant, vector=query_vec, min_confidence=0.9)
        if cache_hit.get("cached", False):
            # Return cached results
            explanation = generate_explanation([cache_hit["expansion"]], [], [], "cache")
            return {"match_type": "exact", "score": cache_hit["confidence"], "explanation": explanation, "match_cert": cache_hit["expansion"]}

        # 2. Vector search (ES)
        results = await self.registry.call("es_search", "topk", vector=query_vec, tenant=tenant)
        best = {"score": 0, "match_type": "no_match", "match_cert": None}
        for r in results:
            vec = fake_embedding(r["source"]["text"].lower())
            sim = cosine_similarity(query_vec, vec)
            if sim > best["score"]:
                best.update(score=sim,
                            match_type=classify_score(sim),
                            match_cert=r["source"]["text"])

        # 3. GPT fallback for low similarity (< 0.7)
        if best["score"] < 0.7:
            gpt_out = await self.registry.call("gpt", "expand_cert", cert)
            best.update(score=gpt_out["confidence"],
                        match_type=classify_score(gpt_out["confidence"]),
                        explanation=gpt_out["explanation"],
                        match_cert=cert)
            # Store result in cache asynchronously (not blocking)
            await self.registry.call("es_cache", "add_cache",
                                    tenant=tenant,
                                    key=cert,
                                    text=cert,
                                    vector=fake_embedding(cert),
                                    confidence=gpt_out["confidence"])

        if "explanation" not in best:
            best["explanation"] = generate_explanation(
                matched = [best["match_cert"]] if best["match_type"] in ("exact", "related") else [],
                related = [],
                missing = [] if best["match_type"] != "no_match" else [cert]
            )
        return best

    async def evaluate(self, tenant, targets, candidates_map):
        results = []
        for cid, cert_list in candidates_map.items():
            matched, related, missing = [], [], []
            total_score = 0
            for target in targets:
                res = await self.evaluate_cert(tenant, target, cert_list)
                if res["match_type"] == "exact":
                    matched.append(res["match_cert"])
                elif res["match_type"] == "related":
                    related.append(res["match_cert"])
                else:
                    missing.append(target)
                total_score += res["score"]
            avg_score = total_score / len(targets) if targets else 0
            explanation = generate_explanation(matched, related, missing)
            results.append({
                "id": cid,
                "matched": matched,
                "related": related,
                "missing": missing,
                "score": avg_score,
                "explanation": explanation
            })
        return results
