import json
from pathlib import Path

SYNONYMS = json.loads(Path("config/synonyms.json").read_text())

def normalize_list(items):
    normalized = []
    for item in items:
        s = item.strip().lower()
        if s.upper() in SYNONYMS:
            s = SYNONYMS[s.upper()].lower()
        normalized.append(s)
    return normalized
