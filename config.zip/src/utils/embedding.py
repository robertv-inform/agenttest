import numpy as np

def fake_embedding(text, dim=768):
    # deterministic pseudo embedding for demonstration only
    np.random.seed(abs(hash(text)) % (2**32))
    vector = np.random.randn(dim).astype(np.float32)
    vector /= np.linalg.norm(vector) + 1e-10
    return vector.tolist()
