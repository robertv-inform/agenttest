from crewai import Agent; from config import MODEL_NAME
def o2c_agent(tools):
    return Agent(name='O2CAgent',role='Fetch SO + Delivery + Billing + Payment',tools=tools,llm=MODEL_NAME,goal='Complete O2C flow.')
