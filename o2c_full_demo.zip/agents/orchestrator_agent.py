from crewai import Agent; from config import MODEL_NAME
def orchestrator_agent():
    return Agent(name='Orchestrator',role='Route tasks',llm=MODEL_NAME,delegation=True,goal='Pick right tool.')
