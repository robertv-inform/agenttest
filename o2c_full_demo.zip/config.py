from dotenv import load_dotenv; load_dotenv()
MODEL_NAME='gpt-4o-mini'
