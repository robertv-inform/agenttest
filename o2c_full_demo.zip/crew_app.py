from crewai import Crew,Task
from agents.o2c_agent import o2c_agent
from agents.orchestrator_agent import orchestrator_agent
from mcp_client import load_tools

tools=load_tools()
o2c=o2c_agent(list(tools.values()))
orc=orchestrator_agent()

task=Task(description='Explain full O2C for a given SalesOrder',agent=orc)
crew=Crew(agents=[orc,o2c],tasks=[task])

if __name__=='__main__':
    while True:
        q=input('You: ')
        print('AI:',crew.run(q))
