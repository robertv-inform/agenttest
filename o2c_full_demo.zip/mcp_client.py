from mcp import Client
def load_tools():
    c=Client('http://localhost:8000')
    return {
        'get_sales_orders':c.get_tool('get_sales_orders'),
        'get_delivery':c.get_tool('get_delivery'),
        'get_billing':c.get_tool('get_billing'),
        'get_payment':c.get_tool('get_payment'),
    }
