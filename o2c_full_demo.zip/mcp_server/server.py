from fastmcp import MCP
from tools import *

mcp=MCP()

@mcp.tool()
def get_sales_orders():
    return load_json('sales_orders.json')

@mcp.tool()
def get_delivery(order_id:str):
    return [d for d in load_json('delivery_docs.json') if d['SalesOrder']==order_id]

@mcp.tool()
def get_billing(order_id:str):
    return [b for b in load_json('billing_docs.json') if b['SalesOrder']==order_id]

@mcp.tool()
def get_payment(order_id:str):
    return [p for p in load_json('payment_docs.json') if p['SalesOrder']==order_id]

if __name__=='__main__':
    mcp.run()
