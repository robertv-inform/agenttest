import json, os

def load_json(name):
    path=os.path.join(os.path.dirname(__file__),'..','data',name)
    with open(path) as f: return json.load(f)
