from crewai import Agent
from config import MODEL_NAME

def create_o2c_agent(tools):
    """Agent that knows full O2C flow and can call MCP tools."""
    return Agent(
        name="O2CAgent",
        role="End-to-end Order-to-Cash expert",
        goal=(
            "Given a SalesOrder ID, fetch Sales Order, Delivery, "
            "Billing, and Payment details via MCP tools and explain "
            "the full O2C lifecycle in simple language."
        ),
        tools=tools,
        llm=MODEL_NAME,
    )
