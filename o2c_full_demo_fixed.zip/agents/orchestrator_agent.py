from crewai import Agent
from config import MODEL_NAME

def create_orchestrator_agent():
    """High-level orchestrator that delegates to O2C agent."""
    return Agent(
        name="Orchestrator",
        role="Routing & coordination agent",
        goal=(
            "Understand the user question and delegate to O2C agent "
            "to fetch and explain Order-to-Cash data."
        ),
        llm=MODEL_NAME,
        delegation=True,
    )
