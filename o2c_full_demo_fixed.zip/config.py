from dotenv import load_dotenv
load_dotenv()

# For this mocked demo, only LLM name is needed
MODEL_NAME = "gpt-4o-mini"
