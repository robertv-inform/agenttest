from crewai import Crew, Task
from agents.o2c_agent import create_o2c_agent
from agents.orchestrator_agent import create_orchestrator_agent
from mcp_client import load_tools

tools = load_tools()
o2c = create_o2c_agent(list(tools.values()))
orchestrator = create_orchestrator_agent()

task = Task(
    description=(
        "When the user gives a SalesOrder ID, call the MCP tools to "
        "get the sales order, delivery, billing, and payment details, "
        "then explain the full Order-to-Cash story."
    ),
    agent=orchestrator,
)

crew = Crew(
    agents=[orchestrator, o2c],
    tasks=[task],
)

if __name__ == "__main__":
    print("Agentic O2C demo ready. Example: 'Explain O2C for 5000000010'")
    while True:
        user_input = input("You: ")
        print("AI:", crew.run(user_input))
