from fastmcp import MCP
from .tools import load_json

mcp = MCP()

@mcp.tool()
def get_sales_orders():
    """Return all mocked sales orders."""
    return load_json("sales_orders.json")

@mcp.tool()
def get_delivery(order_id: str):
    """Return delivery docs for a given SalesOrder."""
    deliveries = load_json("delivery_docs.json")
    return [d for d in deliveries if d["SalesOrder"] == order_id]

@mcp.tool()
def get_billing(order_id: str):
    """Return billing docs for a given SalesOrder."""
    billing_docs = load_json("billing_docs.json")
    return [b for b in billing_docs if b["SalesOrder"] == order_id]

@mcp.tool()
def get_payment(order_id: str):
    """Return payment docs for a given SalesOrder."""
    payment_docs = load_json("payment_docs.json")
    return [p for p in payment_docs if p["SalesOrder"] == order_id]

if __name__ == "__main__":
    # Example: uvicorn-style run is handled internally by fastmcp.MCP
    mcp.run()
