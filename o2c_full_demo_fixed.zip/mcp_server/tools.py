import json
import os

def load_json(name: str):
    """Load a JSON file from the ../data folder."""
    base_dir = os.path.dirname(os.path.dirname(__file__))
    path = os.path.join(base_dir, "data", name)
    with open(path, "r") as f:
        return json.load(f)
