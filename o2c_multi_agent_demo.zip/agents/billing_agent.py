from crewai import Agent
from config import MODEL_NAME

def create_billing_agent(tools):
    return Agent(
        name="BillingAgent",
        role="Billing specialist",
        goal=(
            "Given a SalesOrder ID, fetch billing documents and explain "
            "the invoice, taxes and net value."
        ),
        tools=tools,
        llm=MODEL_NAME,
    )
