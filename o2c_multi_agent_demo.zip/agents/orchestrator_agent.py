from crewai import Agent
from config import MODEL_NAME

def create_orchestrator_agent():
    return Agent(
        name="Orchestrator",
        role="O2C flow orchestrator",
        goal=(
            "Understand the user's question about Order-to-Cash and "
            "delegate sub-tasks to SalesOrder, Delivery, Billing and "
            "Payment agents, then stitch everything into a single story."
        ),
        llm=MODEL_NAME,
        delegation=True,
    )
