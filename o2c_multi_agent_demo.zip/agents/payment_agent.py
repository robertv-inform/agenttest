from crewai import Agent
from config import MODEL_NAME

def create_payment_agent(tools):
    return Agent(
        name="PaymentAgent",
        role="Incoming payment specialist",
        goal=(
            "Given a SalesOrder ID, fetch payment information and explain "
            "payment status and dates in business language."
        ),
        tools=tools,
        llm=MODEL_NAME,
    )
