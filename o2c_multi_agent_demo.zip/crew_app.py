    from crewai import Crew, Task
    from mcp_client import load_tools
    from agents.orchestrator_agent import create_orchestrator_agent
    from agents.sales_order_agent import create_sales_order_agent
    from agents.delivery_agent import create_delivery_agent
    from agents.billing_agent import create_billing_agent
    from agents.payment_agent import create_payment_agent

    tools = load_tools()

    sales_order_agent = create_sales_order_agent(
        [tools["get_sales_orders"], tools["get_sales_order_by_id"]]
    )
    delivery_agent = create_delivery_agent([tools["get_delivery"]])
    billing_agent = create_billing_agent([tools["get_billing"]])
    payment_agent = create_payment_agent([tools["get_payment"]])

    orchestrator = create_orchestrator_agent()

    task = Task(
        description=(
            "When the user gives a SalesOrder ID, coordinate with the four "
            "domain agents to cover the full Order-to-Cash flow: Sales "
            "Order, Delivery, Billing, and Payment. Then respond with a "
            "coherent business explanation."
        ),
        agent=orchestrator,
    )

    crew = Crew(
        agents=[orchestrator, sales_order_agent, delivery_agent, billing_agent, payment_agent],
        tasks=[task],
    )

    if __name__ == "__main__":
        print("Multi-agent O2C demo ready. Example:
"
              "  Explain full O2C for 5000000012")
        while True:
            user_input = input("You: ")
            print("AI:", crew.run(user_input))
