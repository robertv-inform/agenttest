from crewai import Agent
from config import MODEL_NAME

def create_delivery_agent(tools):
    return Agent(
        name="DeliveryAgent",
        role="Outbound delivery specialist",
        goal=(
            "Given a SalesOrder ID, fetch linked delivery documents and "
            "explain picking, packing and goods issue."
        ),
        tools=tools,
        llm=MODEL_NAME,
    )
