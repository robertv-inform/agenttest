from crewai import Agent
from config import MODEL_NAME

def create_orchestrator_agent():
    return Agent(
        name="Orchestrator",
        role="Cross-domain orchestrator for O2C + Weather",
        goal=(
            "Understand the user's question and decide whether it is "
            "about SAP Order-to-Cash (sales order, delivery, billing, "
            "payment) or about weather, then delegate to the correct "
            "specialist agents and synthesize the final answer."
        ),
        llm=MODEL_NAME,
        delegation=True,
    )
