from crewai import Agent
from config import MODEL_NAME

def create_sales_order_agent(tools):
    return Agent(
        name="SalesOrderAgent",
        role="Sales Order specialist",
        goal=(
            "Given a SalesOrder ID, fetch that sales order and summarize "
            "items, value, and customer."
        ),
        tools=tools,
        llm=MODEL_NAME,
    )
