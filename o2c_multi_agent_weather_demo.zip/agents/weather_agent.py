from crewai import Agent
from config import MODEL_NAME

def create_weather_agent(tools):
    return Agent(
        name="WeatherAgent",
        role="Weather & external context specialist",
        goal=(
            "Given a city name, call the MCP weather tool and explain the "
            "temperature forecast in simple language."
        ),
        tools=tools,
        llm=MODEL_NAME,
    )
