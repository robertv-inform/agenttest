from crewai import Crew, Task

from mcp_client_o2c import load_o2c_tools
from mcp_client_weather import load_weather_tools

from agents.orchestrator_agent import create_orchestrator_agent
from agents.sales_order_agent import create_sales_order_agent
from agents.delivery_agent import create_delivery_agent
from agents.billing_agent import create_billing_agent
from agents.payment_agent import create_payment_agent
from agents.weather_agent import create_weather_agent

# Load tools from two different MCP servers
o2c_tools = load_o2c_tools()
weather_tools = load_weather_tools()

# Domain agents
sales_order_agent = create_sales_order_agent(
    [o2c_tools["get_sales_orders"], o2c_tools["get_sales_order_by_id"]]
)
delivery_agent = create_delivery_agent([o2c_tools["get_delivery"]])
billing_agent = create_billing_agent([o2c_tools["get_billing"]])
payment_agent = create_payment_agent([o2c_tools["get_payment"]])
weather_agent = create_weather_agent([weather_tools["weather_forecast"]])

# Orchestrator that delegates
orchestrator = create_orchestrator_agent()

# Single high-level task – routing is handled by LLM + delegation
task = Task(
    description=(
        "When the user asks an SAP O2C question (e.g., explain full "
        "Order-to-Cash for a given SalesOrder ID), delegate to the "
        "O2C agents. When the user asks about weather for a city, "
        "delegate to the WeatherAgent. You can combine both if user "
        "asks how weather might impact deliveries."
    ),
    agent=orchestrator,
)

crew = Crew(
    agents=[
        orchestrator,
        sales_order_agent,
        delivery_agent,
        billing_agent,
        payment_agent,
        weather_agent,
    ],
    tasks=[task],
)

if __name__ == "__main__":
    print("""    Multi-agent O2C + Weather demo ready.

Examples:
  - Explain full O2C flow for 5000000012
  - What is the weather forecast in Bangalore today?
  - For SalesOrder 5000000015, explain O2C and also show Bangalore weather.

""")
    while True:
        user_input = input("You: ")
        print("AI:", crew.run(user_input))
