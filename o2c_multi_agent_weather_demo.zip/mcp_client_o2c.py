from mcp import Client

def load_o2c_tools():
    # O2C fastmcp server, default http://localhost:8000
    client = Client("http://localhost:8000")
    return {
        "get_sales_orders": client.get_tool("get_sales_orders"),
        "get_sales_order_by_id": client.get_tool("get_sales_order_by_id"),
        "get_delivery": client.get_tool("get_delivery"),
        "get_billing": client.get_tool("get_billing"),
        "get_payment": client.get_tool("get_payment"),
    }
