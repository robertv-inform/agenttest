from mcp import Client

def load_weather_tools():
    # Weather fastmcp server, e.g. FASTMCP_PORT=8001 python server.py
    client = Client("http://localhost:8001")
    return {
        "weather_forecast": client.get_tool("weather_forecast"),
    }
