import json
import os

def load_json(name: str):
    base_dir = os.path.dirname(os.path.dirname(__file__))
    path = os.path.join(base_dir, "data", name)
    with open(path, "r") as f:
        return json.load(f)
