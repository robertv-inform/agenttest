from fastmcp import MCP
import requests

mcp = MCP()

# Simple no-key weather using Open-Meteo with hard-coded coords for demo
CITY_COORDS = {
    "bangalore": (12.9716, 77.5946),
    "bengaluru": (12.9716, 77.5946),
    "mumbai": (19.0760, 72.8777),
    "delhi": (28.6139, 77.2090),
    "chennai": (13.0827, 80.2707),
}

@mcp.tool()
def weather_forecast(city: str):
    """Return a simple temperature forecast for a known city (demo)."""
    key = city.lower()
    if key not in CITY_COORDS:
        return {
            "error": f"City '{city}' not configured in demo. "
                     "Try Bangalore, Mumbai, Delhi, or Chennai."
        }
    lat, lon = CITY_COORDS[key]
    url = (
        "https://api.open-meteo.com/v1/forecast"
        f"?latitude={lat}&longitude={lon}&hourly=temperature_2m&forecast_days=1"
    )
    resp = requests.get(url, timeout=10)
    resp.raise_for_status()
    return resp.json()

if __name__ == "__main__":
    # Run separate MCP server, e.g. on port 8001:
    # FASTMCP_PORT=8001 python server.py
    mcp.run()
